<?php 
function bostone_movers_custom_css(){
	global $bostone;
	
	if(!is_admin()) :

		$bostone_custom_css_opt						 = '';
		$bostone_theme_color						 = '';
		$bostone_menu_text_color						 = '';
		$bostone_menu_text_hover_color						 = '';
		$bostone_sticky_menu_bg_color						 = '';
		$bostone_sticky_menu_text_color						 = '';
		$bostone_sticky_menu_text_hover_color						 = '';	
		$bostone_submenu_bg_color						 = '';	
		$bostone_submenu_text_color						 = '';	
		$bostone_submenu_hover_bg_color						 = '';	
		$bostone_submenu_hover_text_color						 = '';	
		$bostone_head_btn_bg_color						 = '';
		$bostone_head_btn_text_color						 = '';
		$bostone_banner_bg_color						 = '';
		$bostone_banner_text_color						 = '';
		$bostone_foot_bgcolor						 = '';
		$bostone_foot_title_color						 = '';
		$bostone_foot_color						 = '';
		$bostone_foot_link_color						 = '';
		$bostone_foot_link_hov_color						 = '';
		$bostone_spinner_bgcolor						 = '';
		$bostone_spinner_bg_border_color						 = '';	
		$bostone_spinner_color						 = '';	
		$bostone_scroll_up_col_icon						 = '';		
		$bostone_scroll_up_col_bg						 = '';		
		$bostone_scroll_up_col_hover_bg						 = '';		
	
				
		if ( isset( $bostone['bostone_custom_css_opt'] ) ) {
			$bostone_custom_css_opt = $bostone['bostone_custom_css_opt'];
		}			
		
		if ( isset( $bostone['bostone_theme_color'] ) ) {
			$bostone_theme_color = $bostone['bostone_theme_color'];
		}		

		if ( isset( $bostone['bostone_menu_text_color'] ) ) {
			$bostone_menu_text_color = $bostone['bostone_menu_text_color'];
		}		
		if ( isset( $bostone['bostone_menu_text_hover_color'] ) ) {
			$bostone_menu_text_hover_color = $bostone['bostone_menu_text_hover_color'];
		}			
		if ( isset( $bostone['bostone_sticky_menu_bg_color'] ) ) {
			$bostone_sticky_menu_bg_color = $bostone['bostone_sticky_menu_bg_color'];
		}		
		if ( isset( $bostone['bostone_sticky_menu_text_color'] ) ) {
			$bostone_sticky_menu_text_color = $bostone['bostone_sticky_menu_text_color'];
		}			
		if ( isset( $bostone['bostone_sticky_menu_text_hover_color'] ) ) {
			$bostone_sticky_menu_text_hover_color = $bostone['bostone_sticky_menu_text_hover_color'];
		}	
					
		if ( isset( $bostone['bostone_submenu_bg_color'] ) ) {
			$bostone_submenu_bg_color = $bostone['bostone_submenu_bg_color'];
		}	
							
		if ( isset( $bostone['bostone_submenu_text_color'] ) ) {
			$bostone_submenu_text_color = $bostone['bostone_submenu_text_color'];
		}
		
		if ( isset( $bostone['bostone_submenu_hover_bg_color'] ) ) {
			$bostone_submenu_hover_bg_color = $bostone['bostone_submenu_hover_bg_color'];
		}	
		
		if ( isset( $bostone['bostone_submenu_hover_text_color'] ) ) {
			$bostone_submenu_hover_text_color = $bostone['bostone_submenu_hover_text_color'];
		}	
		
		if ( isset( $bostone['bostone_head_btn_bg_color'] ) ) {
			$bostone_head_btn_bg_color = $bostone['bostone_head_btn_bg_color'];
		}	
				
		if ( isset( $bostone['bostone_head_btn_text_color'] ) ) {
			$bostone_head_btn_text_color = $bostone['bostone_head_btn_text_color'];
		}	
		
		if ( isset( $bostone['bostone_banner_bg_color'] ) ) {
			$bostone_banner_bg_color = $bostone['bostone_banner_bg_color'];
		}		
		
		if ( isset( $bostone['bostone_banner_text_color'] ) ) {
			$bostone_banner_text_color = $bostone['bostone_banner_text_color'];
		}			
		
		if ( isset( $bostone['bostone_foot_bgcolor'] ) ) {
			$bostone_foot_bgcolor = $bostone['bostone_foot_bgcolor'];
		}	
		
		if ( isset( $bostone['bostone_foot_title_color'] ) ) {
			$bostone_foot_title_color = $bostone['bostone_foot_title_color'];
		}	
		
		if ( isset( $bostone['bostone_foot_color'] ) ) {
			$bostone_foot_color = $bostone['bostone_foot_color'];
		}	
			
		if ( isset( $bostone['bostone_foot_link_color'] ) ) {
			$bostone_foot_link_color = $bostone['bostone_foot_link_color'];
		}	
					
		if ( isset( $bostone['bostone_foot_link_hov_color'] ) ) {
			$bostone_foot_link_hov_color = $bostone['bostone_foot_link_hov_color'];
		}	
		
		if ( isset( $bostone['bostone_spinner_bgcolor'] ) ) {
			$bostone_spinner_bgcolor = $bostone['bostone_spinner_bgcolor'];
		}		
		
		if ( isset( $bostone['bostone_spinner_bg_border_color'] ) ) {
			$bostone_spinner_bg_border_color = $bostone['bostone_spinner_bg_border_color'];
		}		

		if ( isset( $bostone['bostone_spinner_color'] ) ) {
			$bostone_spinner_color = $bostone['bostone_spinner_color'];
		}			

		
		if ( isset( $bostone['bostone_scroll_up_col_icon'] ) ) {
			$bostone_scroll_up_col_icon = $bostone['bostone_scroll_up_col_icon'];
		}		
		
		if ( isset( $bostone['bostone_scroll_up_col_bg'] ) ) {
			$bostone_scroll_up_col_bg = $bostone['bostone_scroll_up_col_bg'];
		}	
		
		if ( isset( $bostone['bostone_scroll_up_col_hover_bg'] ) ) {
			$bostone_scroll_up_col_hover_bg = $bostone['bostone_scroll_up_col_hover_bg'];
		}	

	
	if($bostone_custom_css_opt == true){

	wp_enqueue_style( 'bostone-custom-css', get_template_directory_uri() . '/css/custom-style.css' );
	
	//add custom css
	$bostone_custom_css = "

		body .post__item .post__content .post__title a:hover,
		body .post__item .post__content .post__title a:hover,
		body .post__item.post__related .post__content .post__meta a i,
		body .cmn--btn.outline--theme,
		body .video--btn.btn--white{
			color: {$bostone_theme_color};
		}
		body .cmn--btn.outline--theme{
			border-color: {$bostone_theme_color}!important;
		}
		body .pagination span.page-numbers.current,
		body .cmn--btn.outline--theme:hover,
		body .cmn--btn.outline--theme:focus,
		body .video--btn,
		body .video--btn::before, 
		body .video--btn::after,
		body .road__map-slide-item .road__map-slide-header,
		body .road__map-slide-item .road__map-slide-body::before{
			background-color: {$bostone_theme_color};
		}			
		body .form-submit #submit{
			background-color: {$bostone_theme_color};
			border-color: {$bostone_theme_color};
		}		
		
		body .cmn--btn.btn--rgba::before, 
		body .cmn--btn.btn--white::before, 
		body .cmn--btn, 
		body .toTopBtn, 
		body .road__map__item .road__map__info::after, 
		body .about--list li::before, 
		body .documents-box:hover .documents-box-inner, 
		body .documents-box.active .documents-box-inner, 
		body .documents-box .download-btn, 
		body .team-box:hover .team-content, 
		body .hero-section-2, 
		body .subscribe-form button, 
		body .bg--theme-1,
		body .road__map-slide-item:before,
		body .road__map-slider::before{
			background: {$bostone_theme_color};
		}	


		body .bonus__card-badge,
		body .owl-item:nth-child(2n) .road__map-slide-item .road__map-slide-header::before{
			background: {$bostone_theme_color}!important;
		}
		body .form-submit #submit,
		body #commentform textarea:focus,
		body .form-control:focus,
		body .why__item,
		body .contact__item .contact__icon.cl-11
		{
			border-color: {$bostone_theme_color};
		}	
		
		body .cl-1,
		body .section-name,
		body .contact__item .contact__icon.cl-11{
			color: {$bostone_theme_color}!important;
		}
		body .main-menu li a{
			color: {$bostone_menu_text_color};
		}		
		
		body .main-menu li a:hover,
		body .main-menu li a:focus
		{
			color: {$bostone_menu_text_hover_color};
		}
		body .header-section.active{
			background-color: {$bostone_sticky_menu_bg_color};
		}			
		body .header-section.active .main-menu li a{
			color: {$bostone_sticky_menu_text_color};
		}
		body .header-section.active .main-menu li a:hover,
		body .header-section.active .main-menu li a:focus{
			color: {$bostone_sticky_menu_text_hover_color};
		}		
		
		body .main-menu ul li .sub-menu li{
			background-color: {$bostone_submenu_bg_color};
		}
		body .main-menu ul li .sub-menu li a,
		body .header-section.active .main-menu ul li .sub-menu li a{
			color: {$bostone_submenu_text_color};
		}
		
		body .main-menu ul li .sub-menu li:hover > a{
			color: {$bostone_submenu_hover_text_color}!important;
			background-color: {$bostone_submenu_hover_bg_color}!important;
		}		
		body .header-buttons .cmn--btn.bg--green{
			background-color: {$bostone_head_btn_bg_color}!important;
			color: {$bostone_head_btn_text_color}!important;
		}
		body .footer-section-2.bg--dark{
			background-color: {$bostone_foot_bgcolor}!important;
			
		}	
		body .page-header-section{
			background: {$bostone_banner_bg_color}!important;
			color: {$bostone_banner_text_color}!important;
		}
		body .page-content .breadcrumb li a,
		body .page-content .title,
		.page-content .breadcrumb li{
			color: {$bostone_banner_text_color}!important;
		}
		body .copyright,
		body .copyright a,
		body .footer-bottom.text-white .quick-links li a{
			color: {$bostone_foot_color}!important;
		}
		
		body .footer__title{
			color: {$bostone_foot_title_color}!important;
		}		
		
		body .footer-widget li a{
			color: {$bostone_foot_link_color}!important;
		}		
		
		body .footer-widget li a:hover{
			color: {$bostone_foot_link_hov_color}!important;
		}
		body .overlayer{
			background-color: {$bostone_spinner_bgcolor};
		}
		
		body .overlayer .loader {
			border: 4px solid {$bostone_spinner_color};
		}		
		
		body .toTopBtn.active{
			color: {$bostone_scroll_up_col_icon}!important;
			background: {$bostone_scroll_up_col_bg}!important;
		}		
		
	";
	
	//Add the above custom CSS via wp_add_inline_style
	wp_add_inline_style( 'bostone-custom-css', $bostone_custom_css ); //Pass the variable into the main style sheet ID
	}
	
  endif;
}

add_action( 'wp_enqueue_scripts', 'bostone_movers_custom_css'  ) ;