<?php


add_action( 'cmb2_init', 'bostone_metabox_options' );

function bostone_metabox_options(){
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_bostone_';

	// Page Options	
	$bostone_post_page_opt = new_cmb2_box( array(
		'id'           => $prefix . 'page_option',
		'title'        => esc_html__( 'Options', 'bostone' ),
		'object_types' => array(  'page' , 'post', 'product'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	

	$bostone_post_page_opt->add_field( array(
	    'name'             => esc_html__('Hide Banner ' , 'bostone'),
	    'id'               => $prefix .'hide_banner',
		'desc'    => esc_html__('Check/Uncheck here' , 'bostone'),
	    'type'    => 'checkbox',
	) );
	
	
	$bostone_post_page_opt->add_field( array(
	    'id'               => $prefix .'home_banner_img',
		'name'             => esc_html__('Banner Background Image' , 'bostone'),
	    'desc'             => esc_html__( 'upload image here ','bostone' ),
		 'type'             => 'file',
	) );	
	
	
	//Page Options	
	$bostone_page_options = new_cmb2_box( array(
		'id'           => $prefix . 'page_option',
		'title'        => esc_html__( 'Page Options', 'bostone' ),
		'object_types' => array( 'page'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$bostone_page_options->add_field( array(
	    'id'               => $prefix .'page_logo_opt',
		'name'             => esc_html__('Logo' , 'bostone'),
	    'desc'             => esc_html__( 'upload logo here ','bostone' ),
		 'type'             => 'file',
	) );
	
	$bostone_page_options->add_field( array(
	    'name'             => esc_html__('Header Style' , 'bostone'),
	    'id'               => $prefix .'header_style',
		'desc'    => esc_html__('select from here' , 'bostone'),
	    'type'    => 'select',
		'options'    => array(
			'1'    => 'Style 1',
			'2'    => 'Style 2',
		),
		
		'default'    => '1',
				
	) );	
	
	$bostone_page_options->add_field( array(
	    'name'             => esc_html__('Footer Style' , 'bostone'),
	    'id'               => $prefix .'footer_style',
		'desc'    => esc_html__('select from here' , 'bostone'),
	    'type'    => 'select',
		'options'    => array(
			'1'    => 'Style 1',
			'2'    => 'Style 2',
		),
		
		'default'    => '1',
				
	) );	
	
	
	//Post Options	
	$bostone_post_options = new_cmb2_box( array(
		'id'           => $prefix . 'posts_option',
		'title'        => esc_html__( 'Post Options', 'bostone' ),
		'object_types' => array( 'post'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );	
	
	
	$bostone_post_options->add_field( array(
	    'name'             => esc_html__('Audio / Video Post Embed Code ' , 'bostone'),
	    'id'               => $prefix .'vid_post_title',
	    'type'    => 'title',
	) );		
	
	$bostone_post_options->add_field( array(
	    'name'             => esc_html__('Embed Code' , 'bostone'),
	    'id'               => $prefix .'embed_code',
		'desc'    => esc_html__('enter embed code here' , 'bostone'),
	    'type'    => 'textarea_code',
	) );

	
	//Start Clients Options
	
	$bostone_clients = new_cmb2_box( array(
		'id'           => $prefix . 'clients_options',
		'title'        => esc_html__( 'Clients Info', 'bostone' ),
		'object_types' => array( 'client'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$bostone_clients->add_field( array(
	    'name'             => esc_html__('Website Address' , 'bostone'),
	    'id'               => $prefix .'client_url',
		'type'             => 'text',
		'default'             => '#',
	) );	
		
		
	//Start Timeline Options
	
	$bostone_timeline = new_cmb2_box( array(
		'id'           => $prefix . 'timeline_options',
		'title'        => esc_html__( 'Timeline Info', 'bostone' ),
		'object_types' => array( 'timeline'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$bostone_timeline->add_field( array(
	    'name'             => esc_html__('Date' , 'bostone'),
	    'id'               => $prefix .'timeline_date',
		'type'             => 'text',
		'default'             => 'Dec, 2020',
	) );	
	

		
}