<?php

if ( ! function_exists('bostone_roadmap') ) {

// Register Custom Post Type
function bostone_roadmap() {

	$labels = array(
		'name'                  => esc_html_x( 'Roadmaps', 'Post Type General Name', 'bostone' ),
		'singular_name'         => esc_html_x( 'Roadmap', 'Post Type Singular Name', 'bostone' ),
		'menu_name'             => esc_html__( 'Roadmap', 'bostone' ),
		'name_admin_bar'        => esc_html__( 'Roadmap', 'bostone' ),
		'archives'              => esc_html__( 'Item Archives', 'bostone' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bostone' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bostone' ),
		'all_items'             => esc_html__( 'All Items', 'bostone' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bostone' ),
		'add_new'               => esc_html__( 'Add New', 'bostone' ),
		'new_item'              => esc_html__( 'New Item', 'bostone' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bostone' ),
		'update_item'           => esc_html__( 'Update Item', 'bostone' ),
		'view_item'             => esc_html__( 'View Item', 'bostone' ),
		'view_items'            => esc_html__( 'View Items', 'bostone' ),
		'search_items'          => esc_html__( 'Search Item', 'bostone' ),
		'not_found'             => esc_html__( 'Not found', 'bostone' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bostone' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bostone' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bostone' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bostone' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bostone' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bostone' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bostone' ),
		'items_list'            => esc_html__( 'Items list', 'bostone' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bostone' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bostone' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Roadmap', 'bostone' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-layout',	
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'roadmap', $args );

}
add_action( 'init', 'bostone_roadmap', 0 );

}

if ( ! function_exists('bostone_timeline') ) {

// Register Custom Post Type
function bostone_timeline() {

	$labels = array(
		'name'                  => esc_html_x( 'Timeline', 'Post Type General Name', 'bostone' ),
		'singular_name'         => esc_html_x( 'Timeline', 'Post Type Singular Name', 'bostone' ),
		'menu_name'             => esc_html__( 'Timeline', 'bostone' ),
		'name_admin_bar'        => esc_html__( 'Timeline', 'bostone' ),
		'archives'              => esc_html__( 'Item Archives', 'bostone' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bostone' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bostone' ),
		'all_items'             => esc_html__( 'All Items', 'bostone' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bostone' ),
		'add_new'               => esc_html__( 'Add New', 'bostone' ),
		'new_item'              => esc_html__( 'New Item', 'bostone' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bostone' ),
		'update_item'           => esc_html__( 'Update Item', 'bostone' ),
		'view_item'             => esc_html__( 'View Item', 'bostone' ),
		'view_items'            => esc_html__( 'View Items', 'bostone' ),
		'search_items'          => esc_html__( 'Search Item', 'bostone' ),
		'not_found'             => esc_html__( 'Not found', 'bostone' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bostone' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bostone' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bostone' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bostone' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bostone' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bostone' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bostone' ),
		'items_list'            => esc_html__( 'Items list', 'bostone' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bostone' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bostone' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Timeline', 'bostone' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-layout',	
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'timeline', $args );

}
add_action( 'init', 'bostone_timeline', 0 );

}

if ( ! function_exists('bostone_client') ) {

// Register Client Post Type
function bostone_client() {

	$labels = array(
		'name'                  => esc_html_x( 'Client', 'Post Type General Name', 'bostone' ),
		'singular_name'         => esc_html_x( 'Client', 'Post Type Singular Name', 'bostone' ),
		'menu_name'             => esc_html__( 'Client', 'bostone' ),
		'name_admin_bar'        => esc_html__( 'Client', 'bostone' ),
		'archives'              => esc_html__( 'Item Archives', 'bostone' ),
		'attributes'            => esc_html__( 'Item Attributes', 'bostone' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'bostone' ),
		'all_items'             => esc_html__( 'All Items', 'bostone' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'bostone' ),
		'add_new'               => esc_html__( 'Add New', 'bostone' ),
		'new_item'              => esc_html__( 'New Item', 'bostone' ),
		'edit_item'             => esc_html__( 'Edit Item', 'bostone' ),
		'update_item'           => esc_html__( 'Update Item', 'bostone' ),
		'view_item'             => esc_html__( 'View Item', 'bostone' ),
		'view_items'            => esc_html__( 'View Items', 'bostone' ),
		'search_items'          => esc_html__( 'Search Item', 'bostone' ),
		'not_found'             => esc_html__( 'Not found', 'bostone' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'bostone' ),
		'featured_image'        => esc_html__( 'Featured Image', 'bostone' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'bostone' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'bostone' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'bostone' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'bostone' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'bostone' ),
		'items_list'            => esc_html__( 'Items list', 'bostone' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'bostone' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'bostone' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Client', 'bostone' ),
		'description'           => esc_html__( 'Post Type Description', 'bostone' ),
		'labels'                => $labels,
		'supports'              => array( 'title','thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-nametag',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'client', $args );

}
add_action( 'init', 'bostone_client', 0 );

}
