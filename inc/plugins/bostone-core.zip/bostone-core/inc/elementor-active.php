<?php
/**
 * Elementor Active
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main bostone_Elementor_Active_Extension Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class bostone_Elementor_Active_Extension {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.6';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var bostone_Elementor_Active_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return bostone_Elementor_Active_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {


		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}



	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'bostone' ),
			'<strong>' . esc_html__( 'Bostone Plugin', 'bostone' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bostone' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bostone' ),
			'<strong>' . esc_html__( 'Bostone Plugin', 'bostone' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bostone' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bostone' ),
			'<strong>' . esc_html__( 'Bostone Plugin', 'bostone' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bostone' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {
		
		// Include Widget files
		require_once( __DIR__ . '/elementor/title.php' );
		require_once( __DIR__ . '/elementor/banner.php' );
		require_once( __DIR__ . '/elementor/trade-table.php' );
        require_once( __DIR__ . '/elementor/about.php' );
		require_once( __DIR__ . '/elementor/about-video.php' );
		require_once( __DIR__ . '/elementor/how-work.php' );
		require_once( __DIR__ . '/elementor/why-choose.php' );
		require_once( __DIR__ . '/elementor/feature.php' );
		require_once( __DIR__ . '/elementor/benefits.php' );
		require_once( __DIR__ . '/elementor/buttons.php' );
		require_once( __DIR__ . '/elementor/clients.php' );
		require_once( __DIR__ . '/elementor/pricing-chart.php' );
		require_once( __DIR__ . '/elementor/pricing-chart-two.php' );
		require_once( __DIR__ . '/elementor/pricing-chart-three.php' );
		require_once( __DIR__ . '/elementor/video.php' );
	    require_once( __DIR__ . '/elementor/token-economics.php' );
		require_once( __DIR__ . '/elementor/bonus.php' );
		require_once( __DIR__ . '/elementor/crypto-feature.php' );
		require_once( __DIR__ . '/elementor/app.php' );
		require_once( __DIR__ . '/elementor/token-sale.php' );
		require_once( __DIR__ . '/elementor/countdown.php' );
		require_once( __DIR__ . '/elementor/pre-sale.php' );
		require_once( __DIR__ . '/elementor/roadmap.php' );
		require_once( __DIR__ . '/elementor/timeline.php' );
		require_once( __DIR__ . '/elementor/download.php' );
		require_once( __DIR__ . '/elementor/team.php' );
		require_once( __DIR__ . '/elementor/faq.php' );
		require_once( __DIR__ . '/elementor/contact-info.php' );
		require_once( __DIR__ . '/elementor/contact-form.php' );
		require_once( __DIR__ . '/elementor/contact-us.php' );

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTitleWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneBannerWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTradeTableWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneAboutWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneAboutVideoWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneHowWorkWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneWhyChooseWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneFeatureWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneBenefitsWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneButtonsWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneClientWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostonePricingChartWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostonePricingChartTwoWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostonePricingChartThreeWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneVideoWidget() );
	    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTokenEconomicsWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneBonusWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneCryptoFeatureWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneAppWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTokenSaleWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneCountdownWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostonePresaleWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneRoadmapWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTimelineWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneDownloadWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneTeamWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneFaqWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneContactInfoWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneContactFormWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BostoneContactUsWidget() );
		
	}


}

bostone_Elementor_Active_Extension::instance();