<?php

class bostone_footer_about_Widget extends WP_Widget {
 
    function __construct() {
 
        parent::__construct(
            'bostone-footer-about',  // Base ID
            'Bostone: Footer About'   // Name
        );
 
        add_action( 'widgets_init', function() {
            register_widget( 'bostone_footer_about_Widget' );
        });
 
    }
 
    
 
    public function widget( $args, $instance ) {
 
        echo $args['before_widget'];
 
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
		
		$logo = $instance['logo'];
		$email = $instance['email'];
		$phone = $instance['phone'];
		$fsiname = $instance['fsiname'];
		$fslink = $instance['fslink'];
		$ssiname = $instance['ssiname'];
		$sslink = $instance['sslink'];
		$tsiname = $instance['tsiname'];
		$tslink = $instance['tslink'];
		$fosiname = $instance['fosiname'];
		$foslink = $instance['foslink'];
		
	?>
       
 
     <div class="text-start footer-about">
		<div class="footer-logo mb-25 ms-0">
			<a href="<?php echo esc_url(home_url('/'));?>">
				<img src="<?php echo esc_url($logo);?>" alt="<?php echo esc_attr(get_the_title());?>">
			</a>
		</div>
		<ul class="footer__links widget__contacts">
			<li>
				<?php echo bostone_wp_kses($email);?>
			</li>
			<li>
				<h5 class="m-0 fw--semibold">
					<?php echo bostone_wp_kses($phone);?>
				</h5>
			</li>
		</ul>
		<ul class="social-icons-2 mt-3">
			<?php if($fslink){ ?>
			<li>
				<a href="<?php echo esc_url($fslink);?>">
					<i class="<?php echo esc_attr($fsiname);?>"></i>
				</a>
			</li>
			<?php } if($sslink){ ?>
			<li>
				<a href="<?php echo esc_url($sslink);?>">
					<i class="<?php echo esc_attr($ssiname);?>"></i>
				</a>
			</li>
			<?php } if($tslink){ ?>
			<li>
				<a href="<?php echo esc_url($tslink);?>">
					<i class="<?php echo esc_attr($tsiname);?>"></i>
				</a>
			</li>
			<?php } if($foslink){ ?>
			<li>
				<a href="<?php echo esc_url($foslink);?>">
					<i class="<?php echo esc_attr($fosiname);?>"></i>
				</a>
			</li>
			<?php } ?>
		</ul>
	</div>   
	<?php
	
	echo $args['after_widget'];
    }
 
    public function form( $instance ) {
 
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'bostone' );
        $logo = ! empty( $instance['logo'] ) ? $instance['logo'] : esc_html__( '', 'bostone' );
        $email = ! empty( $instance['email'] ) ? $instance['email'] : esc_html__( '', 'bostone' );
        $phone = ! empty( $instance['phone'] ) ? $instance['phone'] : esc_html__( '', 'bostone' );
        $fsiname = ! empty( $instance['fsiname'] ) ? $instance['fsiname'] : esc_html__( '', 'bostone' );
        $fslink = ! empty( $instance['fslink'] ) ? $instance['fslink'] : esc_html__( '', 'bostone' );
        $ssiname = ! empty( $instance['ssiname'] ) ? $instance['ssiname'] : esc_html__( '', 'bostone' );
        $sslink = ! empty( $instance['sslink'] ) ? $instance['sslink'] : esc_html__( '', 'bostone' );
        $tsiname = ! empty( $instance['tsiname'] ) ? $instance['tsiname'] : esc_html__( '', 'bostone' );
        $tslink = ! empty( $instance['tslink'] ) ? $instance['tslink'] : esc_html__( '', 'bostone' );
        $fosiname = ! empty( $instance['fosiname'] ) ? $instance['fosiname'] : esc_html__( '', 'bostone' );
        $foslink = ! empty( $instance['foslink'] ) ? $instance['foslink'] : esc_html__( '', 'bostone' );
        
		?>
		
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'logo' ) ); ?>"><?php echo esc_html__( 'Enter Logo url:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'logo' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'logo' ) ); ?>" type="text" value="<?php echo esc_attr( $logo ); ?>">
        </p>   

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php echo esc_html__( 'Email Address:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php echo esc_html__( 'Phone Number:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>">
        </p>	
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fsiname' ) ); ?>"><?php echo esc_html__( 'First Social Icon Name:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fsiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fsiname' ) ); ?>" type="text" value="<?php echo esc_attr( $fsiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fslink' ) ); ?>"><?php echo esc_html__( 'First Social Link:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fslink' ) ); ?>" type="text" value="<?php echo esc_attr( $fslink ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'ssiname' ) ); ?>"><?php echo esc_html__( 'Second Social Icon Name:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'ssiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ssiname' ) ); ?>" type="text" value="<?php echo esc_attr( $ssiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'sslink' ) ); ?>"><?php echo esc_html__( 'Second Social Link:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'sslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'sslink' ) ); ?>" type="text" value="<?php echo esc_attr( $sslink ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'tsiname' ) ); ?>"><?php echo esc_html__( 'Third Social Icon Name:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tsiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tsiname' ) ); ?>" type="text" value="<?php echo esc_attr( $tsiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'tslink' ) ); ?>"><?php echo esc_html__( 'Third Social Link:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tslink' ) ); ?>" type="text" value="<?php echo esc_attr( $tslink ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fosiname' ) ); ?>"><?php echo esc_html__( 'Fourth Social Icon Name:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fosiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fosiname' ) ); ?>" type="text" value="<?php echo esc_attr( $fosiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'foslink' ) ); ?>"><?php echo esc_html__( 'Fourth Social Link:', 'bostone' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'foslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'foslink' ) ); ?>" type="text" value="<?php echo esc_attr( $foslink ); ?>">
        </p>
		
        <?php
 
    }
 
    public function update( $new_instance, $old_instance ) {
 
        $instance = array();
 
        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['logo'] = ( !empty( $new_instance['logo'] ) ) ? $new_instance['logo'] : '';
        $instance['email'] = ( !empty( $new_instance['email'] ) ) ? $new_instance['email'] : '';
        $instance['phone'] = ( !empty( $new_instance['phone'] ) ) ? $new_instance['phone'] : '';
        $instance['fsiname'] = ( !empty( $new_instance['fsiname'] ) ) ? $new_instance['fsiname'] : '';
        $instance['fslink'] = ( !empty( $new_instance['fslink'] ) ) ? $new_instance['fslink'] : '';
        $instance['ssiname'] = ( !empty( $new_instance['ssiname'] ) ) ? $new_instance['ssiname'] : '';
        $instance['sslink'] = ( !empty( $new_instance['sslink'] ) ) ? $new_instance['sslink'] : '';
        $instance['tsiname'] = ( !empty( $new_instance['tsiname'] ) ) ? $new_instance['tsiname'] : '';
        $instance['tslink'] = ( !empty( $new_instance['tslink'] ) ) ? $new_instance['tslink'] : '';
        $instance['fosiname'] = ( !empty( $new_instance['fosiname'] ) ) ? $new_instance['fosiname'] : '';
        $instance['foslink'] = ( !empty( $new_instance['foslink'] ) ) ? $new_instance['foslink'] : '';
 
        return $instance;
    }
 
}
$bostone_latest_post = new bostone_footer_about_Widget();

?>