<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class bostoneAboutVideoWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-about-video';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About Video' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_about_video',
			[
				'label' => esc_html__( 'About Video', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'sec_bg_img',
			[
				'label' => esc_html__( 'Background Image', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);	
		
		$this->add_control(
			'sec_vid_url',
			[
				'label' => esc_html__( 'Video Url', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'https://www.youtube.com/watch?v=vQWlgd7hV4A',
			]
		);		
	
		
		$this->end_controls_section();	

	}
	
	protected function render(){		

		$sec_bg_img = $this->get_settings_for_display( 'sec_bg_img' )['url'];
		$sec_vid_url = $this->get_settings_for_display( 'sec_vid_url' );
		
			
		?>
	
		<div class="about--thumb">
			<img src="<?php echo esc_url($sec_bg_img);?>" alt="about">
			<div class="video--wrapper">
				<a href="<?php echo esc_url($sec_vid_url);?>" class="video--btn video-pop">
					<i class="las la-play"></i>
				</a>
			</div>
		</div>
		
								
<?php

	}

}
