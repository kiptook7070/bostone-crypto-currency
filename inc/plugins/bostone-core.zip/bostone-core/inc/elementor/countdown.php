<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneCountdownWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-countdown';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Countdown' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_countdown',
			[
				'label' => esc_html__( 'Countdown', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'sec_countdown_time',
			[
				'label' => esc_html__( 'Counter Time', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '11/09/2022 05:00:00',
			]
		);		

		$this->add_control(
			'sec_countdown_day_text',
			[
				'label' => esc_html__( 'Day Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Days',
			]
		);		
		
		$this->add_control(
			'sec_countdown_hours_text',
			[
				'label' => esc_html__( 'Hours Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Hours',
			]
		);		
		
		$this->add_control(
			'sec_countdown_minutes_text',
			[
				'label' => esc_html__( 'Minutes Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Minutes',
			]
		);		
		
		$this->add_control(
			'sec_countdown_seconds_text',
			[
				'label' => esc_html__( 'Seconds Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Seconds',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		
	
		$sec_countdown_time = $this->get_settings_for_display( 'sec_countdown_time' );
		$sec_countdown_day_text = $this->get_settings_for_display( 'sec_countdown_day_text' );
		$sec_countdown_hours_text = $this->get_settings_for_display( 'sec_countdown_hours_text' );
		$sec_countdown_minutes_text = $this->get_settings_for_display( 'sec_countdown_minutes_text' );
		$sec_countdown_seconds_text = $this->get_settings_for_display( 'sec_countdown_seconds_text' );
		
		
		?>

       <div class="header-countdown bg--light-white">
			<ul class="countdown d-flex flex-wrap justify-content-center cl-white">
				<li>
					<h2 class="title"><span class="days">00</span></h2>
					<p class="days_text"><?php echo esc_html($sec_countdown_day_text);?></p>
				</li>
				<li>
					<h2 class="title"><span class="hours">00</span></h2>
					<p class="hours_text"><?php echo esc_html($sec_countdown_hours_text);?></p>
				</li>
				<li>
					<h2 class="title"><span class="minutes">00</span></h2>
					<p class="minu_text"><?php echo esc_html($sec_countdown_minutes_text);?></p>
				</li>
				<li>
					<h2 class="title"><span class="seconds">00</span></h2>
					<p class="seco_text"><?php echo esc_html($sec_countdown_seconds_text);?></p>
				</li>
			</ul>
		</div>	
		
				
		<script>
		  jQuery(document).ready(function () {
			jQuery('.countdown').countdown({
				date: '<?php echo esc_js($sec_countdown_time);?>',
				offset: +2,
				day: 'Day',
				days: '<?php echo esc_js($sec_countdown_day_text);?>'
			}, 
			function () {
				alert('Done!');
			});
		});
		</script>
					
			
	<?php

	}

}
