<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneBannerWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-banner';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Banner' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_banner',
			[
				'label' => esc_html__( 'Banner', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_banner_style',
			[
				'label' => esc_html__( 'Banner Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( '1', 'bostone' ),
					'2' => esc_html__( '2', 'bostone' ),
					'3' => esc_html__( '3', 'bostone' ),
					'4' => esc_html__( '4', 'bostone' ),
					'5' => esc_html__( '5', 'bostone' ),
				],
			]
		);	

		$this->add_control(
			'sec_banner_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'bostone' ),
				'type' => \Elementor\Controls_Manager::COLOR ,
				'default' => '#0abe81',
			]
		);	
		
		$this->add_control(
			'sec_banner_img',
			[
				'label' => esc_html__( 'Section / BG Image', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);	
		
		$this->add_control(
			'sec_banner_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Powering Data for the new Technology Equity Blockchain ',
			]
		);	
							
		$this->add_control(
			'sec_banner_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' Grursus mal suada faci lisis Lorem ipsum dolarorit mor ametion the consectetur nec odio aea the dumm text. ',
			]
		);		

		$this->add_control(
			'sec_banner_fbtn_text',
			[
				'label' => esc_html__( 'First Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'WHITE PAPER',
			]
		);
		
		$this->add_control(
			'sec_banner_fbtn_link',
			[
				'label' => esc_html__( 'First Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
		
		$this->add_control(
			'sec_banner_sbtn_text',
			[
				'label' => esc_html__( 'Second Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'GET STARTED',
			]
		);
		
		$this->add_control(
			'sec_banner_sbtn_link',
			[
				'label' => esc_html__( 'First Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);			

		$this->add_control(
			'sec_banner_news_shortcode',
			[
				'label' => esc_html__( 'Enter Newsletter Shortcode', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
			]
		);			

		$this->add_control(
			'sec_banner_head_option',
			[
				'label' => esc_html__( 'This Section only for Banner - 1,3', 'bostone' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);	

		$this->add_control(
			'sec_banner_toket_sale_title',
			[
				'label' => esc_html__( 'Token Sale Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Pre-Sale Ends In',
			]
		);			
		
		$this->add_control(
			'sec_banner_toket_sale_pricing_label',
			[
				'label' => esc_html__( 'Token Price Label ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Token Price:',
			]
		);			
		
		$this->add_control(
			'sec_banner_toket_sale_pr_rate',
			[
				'label' => esc_html__( 'Token Sale Price Rate ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '1 BTC = $0.05',
			]
		);		
		
		$this->add_control(
			'sec_banner_toket_sale_w_a_label',
			[
				'label' => esc_html__( 'We Accept Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'We Accept',
			]
		);		

		$this->add_control(
			'sec_banner_toket_av_label',
			[
				'label' => esc_html__( 'Toket Available Text Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Tokens Availablen',
			]
		);		
		
		$this->add_control(
			'sec_banner_toket_av_amount',
			[
				'label' => esc_html__( 'Available Amount', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '+0.55553998 BTC',
			]
		);			
		
		$this->add_control(
			'sec_banner_toket_btn',
			[
				'label' => esc_html__( 'Button', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Buy Tokens Now',
			]
		);		
		
		$this->add_control(
			'sec_banner_toket_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);			
		
		$this->add_control(
			'sec_banner_toket_min_puc_label',
			[
				'label' => esc_html__( 'Minimum Purchase Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Minimum Purchase',
			]
		);	
		
		$this->add_control(
			'sec_banner_toket_min_puc_amount',
			[
				'label' => esc_html__( 'Minimum Purchase Amount', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '+0.4044444 BTC',
			]
		);	
		
		$this->end_controls_section();	

	}
	
	protected function render(){		

		$sec_banner_style = $this->get_settings_for_display( 'sec_banner_style' );
		$sec_banner_img = $this->get_settings_for_display( 'sec_banner_img' )['url'];
		$sec_banner_bg_color = $this->get_settings_for_display( 'sec_banner_bg_color' );
		$sec_banner_title = $this->get_settings_for_display( 'sec_banner_title' );
		$sec_banner_content = $this->get_settings_for_display( 'sec_banner_content' );
		$sec_banner_fbtn_text = $this->get_settings_for_display( 'sec_banner_fbtn_text' );
		$sec_banner_fbtn_link = $this->get_settings_for_display( 'sec_banner_fbtn_link' );
		$sec_banner_sbtn_text = $this->get_settings_for_display( 'sec_banner_sbtn_text' );
		$sec_banner_sbtn_link = $this->get_settings_for_display( 'sec_banner_sbtn_link' );
		$sec_banner_news_shortcode = $this->get_settings_for_display( 'sec_banner_news_shortcode' );
		$sec_banner_toket_sale_title = $this->get_settings_for_display( 'sec_banner_toket_sale_title' );
		$sec_banner_toket_sale_pricing_label = $this->get_settings_for_display( 'sec_banner_toket_sale_pricing_label' );
		$sec_banner_toket_sale_pr_rate = $this->get_settings_for_display( 'sec_banner_toket_sale_pr_rate' );
		$sec_banner_toket_sale_w_a_label = $this->get_settings_for_display( 'sec_banner_toket_sale_w_a_label' );
		$sec_banner_toket_av_label = $this->get_settings_for_display( 'sec_banner_toket_av_label' );
		$sec_banner_toket_av_amount = $this->get_settings_for_display( 'sec_banner_toket_av_amount' );
		$sec_banner_toket_btn = $this->get_settings_for_display( 'sec_banner_toket_btn' );
		$sec_banner_toket_btn_link = $this->get_settings_for_display( 'sec_banner_toket_btn_link' );
		$sec_banner_toket_min_puc_label = $this->get_settings_for_display( 'sec_banner_toket_min_puc_label' );
		$sec_banner_toket_min_puc_amount = $this->get_settings_for_display( 'sec_banner_toket_min_puc_amount' );
		
		?>

		<?php if($sec_banner_style == '2') { ?>
			<!-- Hero Section -->
			<section class="hero-section" style="background: <?php echo esc_attr($sec_banner_bg_color);?>!important">
				<div class="container">
					<div class="hero-wrapper">
						<div class="hero-content">
							<h1 class="hero-title"><span class="d-md-block"><?php echo bostone_wp_kses($sec_banner_title);?></h1>
							<p class="hero-txt">
								<?php echo bostone_wp_kses($sec_banner_content);?>
							</p>
							<div class="hero-button-group">
								<?php if($sec_banner_fbtn_link){ ?>
									<a href="<?php echo esc_html($sec_banner_fbtn_link);?>" class="cmn--btn outline--theme" data-wow-delay=".6s"><?php echo esc_html($sec_banner_fbtn_text);?></a>
								<?php } if($sec_banner_sbtn_link){ ?>
									<a href="<?php echo esc_html($sec_banner_sbtn_link);?>" class="cmn--btn btn-border" data-wow-delay=".8s"><?php echo esc_html($sec_banner_sbtn_text);?></a>
								<?php } ?>
							</div>
						</div>
						<div class="hero-thumb d-none d-lg-block">
							<img src="<?php echo esc_url($sec_banner_img);?>" alt="<?php echo esc_attr($sec_banner_title);?>">
						</div>
					</div>
				</div>
			</section>
			<!-- Hero Section -->		
		
		<?php }elseif($sec_banner_style == '3'){ ?>
		
		   <!-- Hero Section -->
			<section class="hero-section-3" style="background: <?php echo esc_attr($sec_banner_bg_color);?>!important">
				<div class="inset-0 bg--green" style="background-color: <?php echo esc_attr($sec_banner_bg_color);?>!important"></div>
				<div class="bottom-shape d-none d-lg-block">
					<img src="<?php echo esc_url($sec_banner_img);?>" alt="<?php echo esc_attr($sec_banner_title);?>">
				</div>
				<div class="container">
					<div class="hero-wrapper">
						<div class="hero-content hero-content-3 cl-white">
							<h1 class="hero-title"><?php echo bostone_wp_kses($sec_banner_title);?></h1>
							<p class="hero-txt">
								<?php echo bostone_wp_kses($sec_banner_content);?>
							</p>
							<div class="banner-form">
								<?php echo do_shortcode($sec_banner_news_shortcode);?>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Hero Section -->		
			
		<?php }elseif($sec_banner_style == '4'){ ?>
			   <!-- Hero Section -->
				<section class="hero-section-7 clippy--7" style="background: <?php echo esc_attr($sec_banner_bg_color);?>!important">
					<div class="container">
						<div class="hero-wrapper header-wrapper-2 justify-content-between">
							<div class="hero-content cl-white">
								<h1 class="hero-title fw--regular"><?php echo bostone_wp_kses($sec_banner_title);?></h1>
								<p class="hero-txt">
									<?php echo bostone_wp_kses($sec_banner_content);?>
								</p>
								<div class="hero-button-group">
									<?php if($sec_banner_fbtn_link){ ?>
									<a href="<?php echo esc_html($sec_banner_fbtn_link);?>" class="cmn--btn rounded btn--transparent" data-wow-delay=".6s"><?php echo esc_html($sec_banner_fbtn_text);?></a>
									<?php } if($sec_banner_sbtn_link){ ?>
										<a href="<?php echo esc_html($sec_banner_sbtn_link);?>" class="cmn--btn bg-yellow rounded" data-wow-delay=".8s"><?php echo esc_html($sec_banner_sbtn_text);?></a>
									<?php } ?>
								</div>
							</div>
							<div class="hero-token-sell bg-light-white">
								<div class="hero-token-sell-body">
									<h4 class="hero-token-title text-white text-center"><?php echo bostone_wp_kses($sec_banner_title);?></h4>
									<div class="hero-token-area">
										<div class="hero-token-item">
											<h6 class="hero-token-item-title">
												<?php echo esc_html($sec_banner_toket_sale_pricing_label);?>
											</h6>
											<h5 class="token-rate"><?php echo esc_html($sec_banner_toket_sale_pr_rate);?></h5>
										</div>
										<div class="hero-token-item">
											<h6 class="hero-token-item-title">
												<?php echo esc_html($sec_banner_toket_sale_w_a_label);?>
											</h6>
											<ul class="accept-currency">
												<li>
													<i class="las la-dollar-sign"></i>
												</li>
												<li>
													<i class="lab la-bitcoin"></i>
												</li>
												<li>
													<i class="lab la-ethereum"></i>
												</li>
											</ul>
										</div>
									</div>
									<div class="d-flex flex-wrap justify-content-between py-2">
										<span class="m-2 text-white"><?php echo esc_html($sec_banner_toket_av_label);?></span>
										<h5 class="amount m-2 text-white"><?php echo esc_html($sec_banner_toket_av_amount);?></h5>
									</div>
								</div>
								<div class="hero-token-sell-footer">

									<?php if($sec_banner_toket_btn_link){ ?>
										<a href="<?php echo esc_url($sec_banner_toket_btn_link);?>" class="cmn--btn bg-yellow rounded my-2 btn--rgba" data-wow-delay=".8s"><?php echo esc_html($sec_banner_toket_btn);?></a>
									<?php } ?>
									<div class="my-2">
										<span class="text-white"><?php echo esc_html($sec_banner_toket_min_puc_label);?></span>
										<h6 class="min-title text-white m-0"><?php echo esc_html($sec_banner_toket_min_puc_amount);?></h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!-- Hero Section -->
		<?php }elseif($sec_banner_style == '5'){ ?>
		
		   <!-- Hero Section -->
			<section class="hero-section-8 bg--5 " style="background: <?php echo esc_attr($sec_banner_bg_color);?>!important">
				<div class="bottom-shape d-none d-lg-block">
					<img src="<?php echo esc_url($sec_banner_img);?>" alt="<?php echo esc_attr($sec_banner_title);?>">
				</div>
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-10 col-xl-8">
							<div class="hero-wrapper">
								<div class="hero-content hero-content-3 cl-white">
									<h1 class="hero-title"><?php echo bostone_wp_kses($sec_banner_title);?></h1>
									<p class="hero-txt">
										<?php echo bostone_wp_kses($sec_banner_content);?>
									</p>
									<div class="hero-button-group justify-content-center">
										<?php if($sec_banner_fbtn_link){ ?>
										<a href="<?php echo esc_html($sec_banner_fbtn_link);?>" class="cmn--btn btn-pill btn--transparent" data-wow-delay=".6s"><?php echo esc_html($sec_banner_fbtn_text);?></a>
										<?php } if($sec_banner_sbtn_link){ ?>
											<a href="<?php echo esc_html($sec_banner_sbtn_link);?>" class="cmn--btn btn-pill btn--white" data-wow-delay=".8s"><?php echo esc_html($sec_banner_sbtn_text);?></a>
										<?php } ?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Hero Section -->
				
		<?php }else{ ?>		

			<!-- Hero Section -->
			<section class="hero-section-2" style="background: <?php echo esc_attr($sec_banner_bg_color);?>!important">
				<div class="hero-shape bg_img" data-img="<?php echo esc_url($sec_banner_img);?>"></div>
				<div class="container">
					<div class="hero-wrapper header-wrapper-2 justify-content-between">
						<div class="hero-content cl-white">
							<h1 class="hero-title fw--regular"><?php echo bostone_wp_kses($sec_banner_title);?></h1>
							<p class="hero-txt">
								 <?php echo bostone_wp_kses($sec_banner_content);?>
							</p>
							<div class="hero-button-group">
								<?php if($sec_banner_fbtn_link){ ?>
									<a href="<?php echo esc_html($sec_banner_fbtn_link);?>" class="cmn--btn rounded btn--transparent" data-wow-delay=".6s"><?php echo esc_html($sec_banner_fbtn_text);?></a>
								<?php } if($sec_banner_sbtn_link){ ?>
									<a href="<?php echo esc_html($sec_banner_sbtn_link);?>" class="cmn--btn bg--green rounded btn--white" data-wow-delay=".8s"><?php echo esc_html($sec_banner_sbtn_text);?></a>
								<?php } ?>
							</div>
						</div>
						<div class="hero-token-sell">
							<div class="hero-token-sell-body">
								<h4 class="hero-token-title text-white text-center"><?php echo esc_html($sec_banner_toket_sale_title);?></h4>
								<div class="hero-token-area">
									<div class="hero-token-item">
										<h6 class="hero-token-item-title">
											<?php echo esc_html($sec_banner_toket_sale_pricing_label);?>
										</h6>
										<h5 class="token-rate"><?php echo esc_html($sec_banner_toket_sale_pr_rate);?></h5>
									</div>
									<div class="hero-token-item">
										<h6 class="hero-token-item-title">
											<?php echo esc_html($sec_banner_toket_sale_w_a_label);?>
										</h6>
										<ul class="accept-currency">
											<li>
												<i class="las la-dollar-sign"></i>
											</li>
											<li>
												<i class="lab la-bitcoin"></i>
											</li>
											<li>
												<i class="lab la-ethereum"></i>
											</li>
										</ul>
									</div>
								</div>
								<div class="d-flex flex-wrap justify-content-between py-2">
									<span class="m-2 text-white"><?php echo esc_html($sec_banner_toket_av_label);?></span>
									<h5 class="amount m-2 text-white"><?php echo esc_html($sec_banner_toket_av_amount);?></h5>
								</div>
							</div>
							<div class="hero-token-sell-footer">
								<?php if($sec_banner_toket_btn_link){ ?>
									<a href="<?php echo esc_url($sec_banner_toket_btn_link);?>" class="cmn--btn bg--green rounded btn--white my-2" data-wow-delay=".8s"><?php echo esc_html($sec_banner_toket_btn);?></a>
								<?php } ?>
								<div class="my-2">
									<span class="text-white"><?php echo esc_html($sec_banner_toket_min_puc_label);?></span>
									<h6 class="min-title text-white m-0"><?php echo esc_html($sec_banner_toket_min_puc_amount);?></h6>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Hero Section -->
		<?php } ?>
			
	<?php
		
	}

}
