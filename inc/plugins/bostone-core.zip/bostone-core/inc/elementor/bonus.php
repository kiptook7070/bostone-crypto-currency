<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneBonusWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-bonus';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Bonus Stage' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_bonus',
			[
				'label' => esc_html__( 'Bonus', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'bon_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Stage 1'
			]
		);		
		
			
		$this->add_control(
			'bon_period',
			[
				'label' => esc_html__( 'Period', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Sep 24 - Oct 5'
			]
		);			
		
		$this->add_control(
			'bon_dis',
			[
				'label' => esc_html__( 'Discount', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '25% Discount'
			]
		);	

		$this->add_control(
			'bon_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Buy Now'
			]
		);			
		
		$this->add_control(
			'bon_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#'
			]
		);	
	
	
		$this->end_controls_section();

	}
	
	protected function render(){		

		$bon_title = $this->get_settings_for_display( 'bon_title' );
		$bon_period = $this->get_settings_for_display( 'bon_period' );
		$bon_dis = $this->get_settings_for_display( 'bon_dis' );
		$bon_btn_text = $this->get_settings_for_display( 'bon_btn_text' );
		$bon_btn_link = $this->get_settings_for_display( 'bon_btn_link' );
		
		?>

		<div class="bonus__card">
			<h5 class="bonus__card-title"><?php echo esc_html($bon_title);?></h5>
			<h6 class="bonus__card-subtitle"><?php echo esc_html($bon_period);?></h6>
			<span class="bonus__card-badge bg--green"><?php echo esc_html($bon_dis);?></span>
			<?php if($bon_btn_link){ ?>
				<a href="<?php echo esc_url($bon_btn_link);?>"><?php echo esc_html($bon_btn_text);?></a>
			<?php } ?>
		</div>
		
<?php
	}

}