<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostonePresaleWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-presale';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Presale' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_presale',
			[
				'label' => esc_html__( 'Pre Sale', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'bostone_presale_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'One', 'bostone' ),
					'2' => esc_html__( 'Two', 'bostone' ),
					'3' => esc_html__( 'Three', 'bostone' ),
				],
			]
		);	
		
		$this->add_control(
			'sec_presale_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Private Pre-Sale',
			]
		);		

		$this->add_control(
			'sec_presale_info',
			[
				'label' => esc_html__( 'Info', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => ' May 15,2021 ',
			]
		);		

		
		$this->end_controls_section();

	}
	
	protected function render(){		
	
		$bostone_presale_style = $this->get_settings_for_display( 'bostone_presale_style' );
		$sec_presale_title = $this->get_settings_for_display( 'sec_presale_title' );
		$sec_presale_info = $this->get_settings_for_display( 'sec_presale_info' );
		
		if($bostone_presale_style == '1' || $bostone_presale_style == '2'){
		
		?>

		<div class="structure-item <?php if($bostone_presale_style =='1'){ echo esc_attr('bg-white');}else{ echo esc_attr('bg--light-white');}?>">
			<h6 class="structure-title"><?php echo esc_html($sec_presale_title);?></h6>
			<span class="info"><?php echo esc_html($sec_presale_info);?></span>
		</div>
		<?php }else{ ?>
		<div class="token__item-5">
			<h6 class="title cl-11"><?php echo esc_html($sec_presale_title);?></h6>
			<span><?php echo esc_html($sec_presale_info);?></span>
		</div>
  
	<?php
		}

	}

}
