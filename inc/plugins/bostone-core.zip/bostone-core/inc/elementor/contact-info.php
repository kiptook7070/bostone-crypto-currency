<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneContactInfoWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-contact-info';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Contact Info' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_contact_info',
			[
				'label' => esc_html__( 'Contact Info', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Contact',
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Get in touch with us',
			]
		);			
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'con_icon', [
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);				
		
		$repeater->add_control(
			'con_title', [
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'con_content', [
				'label' => esc_html__( 'Content ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'con_list',
			[
				'label' => esc_html__
				( 'Contact List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'con_icon' => 'las la-phone-volume',									
						'con_title' => 'Call us on: +03601 885399',									
						'con_content' => ' Our office hours are Monday – Friday, 9 am-6 pm ',																										
					],
		
				],
			]
		);		
				
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$con_list = $this->get_settings_for_display( 'con_list' );
	
		?>

		<div class="contact__wrapper h-100 con_info_area">
			<div class="section-header mb-4">
				<h6 class="section-name cl-11 mb-3"><?php echo esc_html($sec_subtitle);?></h6>
				<h2 class="section-title"><?php echo bostone_wp_kses($sec_title);?></h2>
			</div>
			<div class="row g-4">

				<?php		
				foreach ($con_list as $item ) { 
														
				?>	
				
					<div class="col-12">
						<div class="contact__item">
							<div class="contact__icon cl-11">
								<i class="<?php echo esc_attr($item['con_icon']);?>"></i>
							</div>
							<div class="contact__content">
								<h6 class="title"><?php echo esc_html($item['con_title']);?></h6>
								<span class="info"><?php echo bostone_wp_kses($item['con_content']);?></span>
							</div>
						</div>
					</div>
				<?php 
			
				}
				?>			


			</div>
		</div>		
		
<?php
	}

}
