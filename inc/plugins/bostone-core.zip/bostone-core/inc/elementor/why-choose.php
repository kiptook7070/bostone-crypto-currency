<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneWhyChooseWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-why-choose';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Why Choose' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_why_choose',
			[
				'label' => esc_html__( 'Why Choose', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'choose_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'choose_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Blockchain Infrastructure',
			]
		);	
		
		$this->add_control(
			'choose_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'There are many variations of passages of the Lorem Ipsum majority have read injected the humour.',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$choose_icon = $this->get_settings_for_display( 'choose_icon' )['url'];
		$choose_title = $this->get_settings_for_display( 'choose_title' );
		$choose_content = $this->get_settings_for_display( 'choose_content' );
		
		?>
	
		<div class="why__item">
			<div class="why__thumb">
				<img src="<?php echo esc_url($choose_icon);?>" alt="<?php echo esc_attr($choose_title);?>" />
			</div>
			<div class="why__content">
				<h4 class="why__title"><?php echo esc_html($choose_title);?></h4>
				<p class="why__text">
					<?php echo bostone_wp_kses($choose_content);?>
				</p>
			</div>
		</div>	
		
<?php
	}

}
