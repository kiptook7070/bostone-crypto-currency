<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



class BostoneTimelineWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-timeline';
	}
	
	public function get_title() {
		return esc_html__('Timeline' , 'bostone');
	}

	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_timeline_content',
			[
				'label' => esc_html__( 'Timeline', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Roadmap',
			]
		);		
		
		$this->add_control(
			'number_of_post',
			[
				'label' => esc_html__( 'Number of Posts', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '-1',
			]
		);		

				
		
		$this->end_controls_section();
		
		

	}
	
	protected function render(){

		$sec_title = $this->get_settings_for_display( 'sec_title' );	
		$number_of_post = $this->get_settings_for_display( 'number_of_post' );

		?>

	   <!-- Road Map Section -->
		<section class="road-map-section pt-120 pb-60 bg--7" id="road">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-6">
						<div class="section-header section-header-center">
							<div class="titles-area">
								<h2 class="section-title text-white fw-normal"><?php echo esc_html($sec_title);?></h2>
							</div>
						</div>
					</div>
				</div>
				
				<div class="road__map-area text-light">
				<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'timeline' ),
						'posts_per_page'         => $number_of_post,
					);

					// The Query
					$bostone_roadmap_query = new WP_Query( $args );

					// The Loop
					if ( $bostone_roadmap_query->have_posts() ) {
						while ( $bostone_roadmap_query->have_posts() ) {
							$bostone_roadmap_query->the_post();
							$bostone_timeline_date = get_post_meta(get_the_ID(), '_bostone_timeline_date', true); 
							
							?>
							 <div class="road__map-item">
								<h5 class="subtitle text-white"><?php echo esc_html($bostone_timeline_date);?></h5>
								<div class="road__map-content">
									<h5 class="title"><?php the_title();?></h5>
									<p>
										<?php the_content();?>
									</p>
								</div>
							</div>
			
				
					<?php }
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
					?>
					
				</div>
			</div>
		</section>
		<!-- Road Map Section -->


		<?php 
	
	}

}
