<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneDownloadWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-download';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Download' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_download',
			[
				'label' => esc_html__( 'Download', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_dwn_active',
			[
				'label' => esc_html__( 'Active', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Yes', 'bostone' ),
					'2' => esc_html__( 'No', 'bostone' ),
				],
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'White Papers',
			]
		);
		
		$this->add_control(
			'sec_thumb',
			[
				'label' => esc_html__( 'Thumb', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		

		$this->add_control(
			'sec_dwn_link',
			[
				'label' => esc_html__( 'Download Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);			
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'dwn_info_lan_text', [
				'label' => esc_html__( 'Language Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);				
		
		$repeater->add_control(
			'dwn_info_lan_link', [
				'label' => esc_html__( 'Language Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'dwn_info_lan',
			[
				'label' => esc_html__
				( 'Download List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'dwn_info_lan_text' => 'ENG',									
						'dwn_info_lan_link' => '#',																																			
					],
		
				],
			]
		);		
				
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_dwn_active = $this->get_settings_for_display( 'sec_dwn_active' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_thumb = $this->get_settings_for_display( 'sec_thumb' )['url'];
		$sec_dwn_link = $this->get_settings_for_display( 'sec_dwn_link' );
		$dwn_info_lan = $this->get_settings_for_display( 'dwn_info_lan' );
	
		?>

		<div class="documents-box <?php if($sec_dwn_active == '1'){ echo esc_attr('active');}?>">
			<div class="documents-box-inner">
				<div class="info">
					<?php		
						foreach ($dwn_info_lan as $item ) { 
																
						?>	
							<a href="<?php echo esc_url($item['dwn_info_lan_link']);?>"><?php echo esc_html($item['dwn_info_lan_text']);?></a>
					<?php } ?>	
				</div>
				<div class="documents-thumb">
					<img src="<?php echo esc_url($sec_thumb);?>" alt="documents">
				</div>
				<div class="documents-content">
					<h5 class="title"><?php echo esc_html($sec_title);?></h5>
				</div>
			</div>
			<a href="<?php echo esc_url($sec_dwn_link);?>" class="download-btn">
				<i class="fas fa-download"></i>
			</a>
		</div>

<?php
	}

}