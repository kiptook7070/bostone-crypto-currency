<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneTitleWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-title';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Title' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
				),
				'default' => '1',
			]
		);
		
		$this->add_control(
			'sec_title_color',
			[
				'label' => esc_html__( 'Color', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => 'Black',
					'2' => 'White',
				),
				'default' => '1',
			]
		);
	
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'SubHeading Text',
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Heading Text',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		
		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_title_color = $this->get_settings_for_display( 'sec_title_color' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		
		if($sec_style == '2'){ ?>
		<div class="section-header section-header-center <?php if($sec_title_color== '2'){ echo esc_attr('cl-white');}?>">
			<h6 class="section-name cl-1"><?php echo bostone_wp_kses($sec_subtitle);?></h6>
			<h2 class="section-title"><?php echo bostone_wp_kses($sec_title);?></h2>
			<?php if($sec_content){ ?>
			<p class="section-text">
				<?php echo bostone_wp_kses($sec_content);?>
			</p>
			<?php } ?>
		</div>
		<?php }elseif($sec_style == '3'){ ?>
		<div class="container">
			<div class="section-header section-header-2 <?php if($sec_title_color== '2'){ echo esc_attr('cl-white');}?>">
				<div class="titles-area">
					<h6 class="section-name"><?php echo bostone_wp_kses($sec_subtitle);?></h6>
					<h2 class="section-title"><?php echo bostone_wp_kses($sec_title);?></h2>
				</div>
				<?php if($sec_content){ ?>
				<p class="section-text">
					<?php echo bostone_wp_kses($sec_content);?>
				</p>
				<?php } ?>
			</div>       
         </div>
		<?php }else{ ?>
	
		<div class="section-header section-header-center <?php if($sec_title_color== '2'){ echo esc_attr('cl-white');}?>">
			<h3 class="section-title fw--medium"><?php echo bostone_wp_kses($sec_title);?></h3>
			<?php if($sec_content){ ?>
				<p>
					<?php echo bostone_wp_kses($sec_content);?>
				</p>
			<?php } ?>
		</div>
		
<?php
		}
	}

}
