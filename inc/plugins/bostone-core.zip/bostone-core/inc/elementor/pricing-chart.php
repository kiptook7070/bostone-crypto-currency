<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostonePricingChartWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-pricing-chart';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Pricing Chart' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_pricing_chart',
			[
				'label' => esc_html__( 'Pricing Chart', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'pri_shape',
			[
				'label' => esc_html__( 'Shape', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		

		$this->add_control(
			'pri_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Pricing Charts',
			]
		);	
		
		$this->add_control(
			'pri_enter_js_code',
			[
				'label' => esc_html__( 'Enter JS Code', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
			]
		);	

		$this->end_controls_section();

	}
	
	protected function render(){		

		$pri_shape = $this->get_settings_for_display( 'pri_shape' )['url'];
		$pri_title = $this->get_settings_for_display( 'pri_title' );
		$pri_enter_js_code = $this->get_settings_for_display( 'pri_enter_js_code' );
		
		?>


		<!-- Pricing Charts Section -->
		<section class="pricing-charts-section overflow-hidden pt-120 pb-60 pt-lg-1 position-relative">
			<div class="bottom-shape-2 d-none d-lg-block">
				<img src="<?php echo esc_url($pri_shape);?>" alt="<?php echo esc_attr($pri_title);?>">
			</div>
			<div class="container position-relative">
				<div class="section-header-3">
					<h2 class="title fw-medium"><?php echo esc_html($pri_title);?></h2>
				</div>
				<div id="chart_div" class="pricing-chart"></div>
			</div>
		</section>
		<!-- Pricing Charts Section -->
	
		<!-- Pricing Google Charts -->
		<script>
			<?php echo $pri_enter_js_code;?>
		</script>
		<!-- Pricing Google Charts -->
<?php
	}

}
