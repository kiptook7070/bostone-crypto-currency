<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneTokenSaleWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-token-sale';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Token Sale' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_token_sale',
			[
				'label' => esc_html__( 'Token Sale', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'sec_token_counter_time',
			[
				'label' => esc_html__( 'Counter Time', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '11/09/2022 05:00:00',
			]
		);		

		$this->add_control(
			'sec_token_day_text',
			[
				'label' => esc_html__( 'Day Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Days',
			]
		);		
		
		$this->add_control(
			'sec_token_hours_text',
			[
				'label' => esc_html__( 'Hours Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Hours',
			]
		);		
		
		$this->add_control(
			'sec_token_minutes_text',
			[
				'label' => esc_html__( 'Minutes Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Minutes',
			]
		);		
		
		$this->add_control(
			'sec_token_seconds_text',
			[
				'label' => esc_html__( 'Seconds Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Seconds',
			]
		);		
		
		$this->add_control(
			'sec_sale_raised_text',
			[
				'label' => esc_html__( 'Sale Raised Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Sale Raised',
			]
		);		

		$this->add_control(
			'sec_sale_raised',
			[
				'label' => esc_html__( 'Sale Raised', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '35,000 BCC',
			]
		);		
		
		$this->add_control(
			'sec_soft_caps_text',
			[
				'label' => esc_html__( 'Soft Caps Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Soft-caps',
			]
		);		
		
		$this->add_control(
			'sec_soft_caps',
			[
				'label' => esc_html__( 'Soft Caps', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '80,000 BCC',
			]
		);		
		
		$this->add_control(
			'sec_ts_percent_number',
			[
				'label' => esc_html__( 'Percent', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '57',
			]
		);
		
		
		$this->add_control(
			'sec_ts_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Buy Token',
			]
		);			
		
		$this->add_control(
			'sec_ts_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);			
		
		$this->add_control(
			'sec_ts_pay_logo',
			[
				'label' => esc_html__( 'Payment Logo', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
	
		
		$this->end_controls_section();

	}
	
	protected function render(){		
	
		$sec_token_counter_time = $this->get_settings_for_display( 'sec_token_counter_time' );
		$sec_token_day_text = $this->get_settings_for_display( 'sec_token_day_text' );
		$sec_token_hours_text = $this->get_settings_for_display( 'sec_token_hours_text' );
		$sec_token_minutes_text = $this->get_settings_for_display( 'sec_token_minutes_text' );
		$sec_token_seconds_text = $this->get_settings_for_display( 'sec_token_seconds_text' );
		$sec_sale_raised_text = $this->get_settings_for_display( 'sec_sale_raised_text' );
		$sec_sale_raised = $this->get_settings_for_display( 'sec_sale_raised' );
		$sec_soft_caps_text = $this->get_settings_for_display( 'sec_soft_caps_text' );
		$sec_soft_caps = $this->get_settings_for_display( 'sec_soft_caps' );
		$sec_ts_percent_number = $this->get_settings_for_display( 'sec_ts_percent_number' );
		$sec_ts_btn_text = $this->get_settings_for_display( 'sec_ts_btn_text' );
		$sec_ts_btn_link = $this->get_settings_for_display( 'sec_ts_btn_link' );
		$sec_ts_pay_logo = $this->get_settings_for_display( 'sec_ts_pay_logo' )['url'];
		
		?>
			
		<div class="structure-wrapper bg-white">
			<div class="structure-header border-bottom">
				<ul class="countdown d-flex flex-wrap justify-content-center">
					<li>
						<h2 class="title"><span class="days">00</span></h2>
						<p class="days_text"><?php echo esc_html($sec_token_day_text);?></p>
					</li>
					<li>
						<h2 class="title"><span class="hours">00</span></h2>
						<p class="hours_text"><?php echo esc_html($sec_token_hours_text);?></p>
					</li>
					<li>
						<h2 class="title"><span class="minutes">00</span></h2>
						<p class="minu_text"><?php echo esc_html($sec_token_minutes_text);?></p>
					</li>
					<li>
						<h2 class="title"><span class="seconds">00</span></h2>
						<p class="seco_text"><?php echo esc_html($sec_token_seconds_text);?></p>
					</li>
				</ul>
			</div>
			<div class="structure-body">
				<div class="progress-item">
					<div class="d-flex flex-wrap justify-content-between fw--semibold mb-1">
						<span><?php echo esc_html($sec_sale_raised_text);?></span>
						<span><?php echo esc_html($sec_soft_caps_text);?></span>
					</div>
					<div class="progress">
						<div class="progress-bar" role="progressbar" style="width: <?php echo esc_attr($sec_ts_percent_number);?>%;" aria-valuenow="<?php echo esc_attr($sec_ts_percent_number);?>" aria-valuemin="0" aria-valuemax="100"></div>
					</div>
					<div class="d-flex flex-wrap justify-content-between fw--semibold mt-1">
						<span><?php echo esc_html($sec_sale_raised);?></span>
						<span><?php echo esc_html($sec_soft_caps);?></span>
					</div>
				</div>
				<div class="d-flex flex-wrap align-items-center justify-content-between mt-2">
					<?php if($sec_ts_btn_link){ ?>
						<a href="<?php echo esc_html($sec_ts_btn_link);?>" class="cmn--btn mt-2 mr-2"><?php echo esc_html($sec_ts_btn_text);?></a>
					<?php } ?>
					<div class="gateways mt-2">
						<img src="<?php echo esc_url($sec_ts_pay_logo);?>" class="mw-100" alt="payment">
					</div>
				</div>
			</div>
		</div>
					
		<script>
		  jQuery(document).ready(function () {
			jQuery('.countdown').countdown({
				date: '<?php echo esc_js($sec_token_counter_time);?>',
				offset: +2,
				day: 'Day',
				days: 'Days'
			}, 
				function () {
					alert('Done!');
				});
			});
		</script>
					
			
	<?php

	}

}
