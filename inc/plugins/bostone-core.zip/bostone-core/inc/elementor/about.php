<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneAboutWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-about';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_about',
			[
				'label' => esc_html__( 'About', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_about_style',
			[
				'label' => esc_html__( 'About Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'One', 'bostone' ),
					'2' => esc_html__( 'Two', 'bostone' ),
					'3' => esc_html__( 'Three', 'bostone' ),
				],
			]
		);	
		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'about the Boston ?',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Investment To The Future Business Technology',
			]
		);		

		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in that some injected humour or randomised look even slightly believable. ',
			]
		);		
		
		$this->add_control(
			'sec_full_content',
			[
				'label' => esc_html__( 'Full Content (Style 3 )', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => '',
			]
		);	


		$this->add_control(
			'sec_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Learn More',
			]
		);		
		
		$this->add_control(
			'sec_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);
		
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'sec_about_icon', [
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'sec_about_content', [
				'label' => esc_html__( 'About Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'sec_about_list',
			[
				'label' => esc_html__
				( 'About Content List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'sec_about_icon' => '',									
						'sec_about_content' => 'There many variations of that passages. ',																										
					],
		
				],
			]
		);		
		
		$this->end_controls_section();			
	}
	
	protected function render(){		

		$sec_about_style = $this->get_settings_for_display( 'sec_about_style' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_full_content = $this->get_settings_for_display( 'sec_full_content' );
		$sec_about_list = $this->get_settings_for_display( 'sec_about_list' );
		$sec_btn_text = $this->get_settings_for_display( 'sec_btn_text' );
		$sec_btn_link = $this->get_settings_for_display( 'sec_btn_link' );
		
		if($sec_about_style == '2'){
			
		?>
		
		<div class="about--content">
			<div class="section-header mb-4">
				<h6 class="section-name cl-1"><?php echo bostone_wp_kses($sec_subtitle);?></h6>
				<h2 class="section-title"><?php echo bostone_wp_kses($sec_title);?></h2>
				<p class="section-text"><?php echo bostone_wp_kses($sec_content);?></p>
			</div>
			<ul class="about--list">
				<?php
				foreach ($sec_about_list as $item ) { ?>																									
					<li>
						<?php echo esc_html($item['sec_about_content']);?>
					</li>

				<?php } ?>

			</ul>
			
			<?php if($sec_btn_link){ ?>
				<a href="<?php echo esc_html($sec_btn_link);?>" class="cmn--btn mt-4 outline--theme" data-wow-delay=".3s"><?php echo esc_html($sec_btn_text);?></a>
			<?php } ?>
		</div>
	
		<?php }elseif($sec_about_style == '3'){ ?>
		
			<div class="about--content">
				<div class="section-header mb-4">
					<?php if($sec_subtitle){ ?>
					<h6 class="section-name cl--green"><?php echo bostone_wp_kses($sec_subtitle);?></h6>
					<?php } ?>
					<h2 class="section-title"><?php echo bostone_wp_kses($sec_title);?></h2>
					<p class="section-text quote__txt"><?php echo bostone_wp_kses($sec_content);?></p>
				</div>
				
				<?php echo bostone_wp_kses($sec_full_content);?>
				
			</div>	
			
		<?php }else{ ?>
		
		<div class="about--content">
			<div class="section-header mb-4">
				<h6 class="section-name cl-2"><?php echo bostone_wp_kses($sec_subtitle);?></h6>
				<h2 class="section-title fw--regular"><?php echo bostone_wp_kses($sec_title);?></h2>
				<p class="section-text"><?php echo bostone_wp_kses($sec_content);?></p>
			</div>
			<div class="row g-4 justify-content-center">
				<?php
				foreach ($sec_about_list as $item ) { ?>																									
		
					<div class="col-sm-6">
						<div class="about__list__card">
							<div class="about__list__card-icon">
								<img src="<?php echo esc_url($item['sec_about_icon']['url']);?>" alt="about" />
							</div>
							<div class="about__list__card-cont">
								<?php echo esc_html($item['sec_about_content']);?>
							</div>
						</div>
					</div>
				
				<?php } ?>

			</div>
		</div>		
		
		<?php } ?>
		
								
<?php

	}

}
