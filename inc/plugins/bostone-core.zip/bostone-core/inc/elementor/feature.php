<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneFeatureWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-feature';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Feature' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_feature',
			[
				'label' => esc_html__( 'Feature', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'feat_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'feat_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Lowest Cost',
			]
		);	
		
		$this->add_control(
			'feat_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'There are many variations of passages of the Lorem Ipsum majority have read injected the humour.',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$feat_icon = $this->get_settings_for_display( 'feat_icon' )['url'];
		$feat_title = $this->get_settings_for_display( 'feat_title' );
		$feat_content = $this->get_settings_for_display( 'feat_content' );
		
		?>

		<div class="feature-item">
			<div class="feature-thumb">
				<img src="<?php echo esc_url($feat_icon);?>" alt="<?php echo esc_attr($feat_title);?>" />
			</div>
			<div class="feature-content">
				<h5 class="title"><?php echo esc_html($feat_title);?></h5>
				<p>
					<?php echo bostone_wp_kses($feat_content);?>
				</p>
			</div>
		</div>	

<?php
	}

}
