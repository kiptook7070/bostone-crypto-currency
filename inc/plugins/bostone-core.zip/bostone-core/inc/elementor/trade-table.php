<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneTradeTableWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-trade-table';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Trade Table' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_trade_table',
			[
				'label' => esc_html__( 'Trade Table', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'trade_number_label',
			[
				'label' => esc_html__( 'Number Label', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);		

		$this->add_control(
			'trade_name_label',
			[
				'label' => esc_html__( 'Name', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Name',
			]
		);	
		
		$this->add_control(
			'trade_price_label',
			[
				'label' => esc_html__( 'Price', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Price',
			]
		);	
		
		$this->add_control(
			'trade_change_label',
			[
				'label' => esc_html__( 'Change', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Change',
			]
		);		
		
		$this->add_control(
			'trade_chart_label',
			[
				'label' => esc_html__( 'Chart', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Chart',
			]
		);				
		
		$this->add_control(
			'trade_Trade_label',
			[
				'label' => esc_html__( 'Trade', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Trade',
			]
		);		
			
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'trade_currency_logo', [
				'label' => esc_html__( 'Currency Logo', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);		
				
		$repeater->add_control(
			'trade_currency_name', [
				'label' => esc_html__( 'Name', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
						
		$repeater->add_control(
			'trade_currency_info', [
				'label' => esc_html__( 'Info', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);	
		
		$repeater->add_control(
			'trade_currency_price', [
				'label' => esc_html__( 'Price', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'trade_currency_change', [
				'label' => esc_html__( 'Change', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);			
		
		
		$repeater->add_control(
			'trade_currency_graph', [
				'label' => esc_html__( 'Graph Image', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'trade_btn_text', [
				'label' => esc_html__( 'Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'trade_btn_link', [
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'trade_list',
			[
				'label' => esc_html__
				( 'Trade List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'trade_currency_logo' => 'Bitcoin',									
						'trade_currency_name' => 'Bitcoin',									
						'trade_currency_info' => 'BTC',									
						'trade_currency_price' => '$ 4,751.50',									
						'trade_currency_change' => '+0.83%',									
						'trade_currency_graph' => '',									
						'trade_btn_text' => 'Buy',																										
						'trade_btn_link' => '#',																										
					],
		
				],
			]
		);	

		
		$this->end_controls_section();

	}
	
	protected function render(){		
	
		$trade_number_label = $this->get_settings_for_display( 'trade_number_label' );
		$trade_name_label = $this->get_settings_for_display( 'trade_name_label' );
		$trade_price_label = $this->get_settings_for_display( 'trade_price_label' );
		$trade_change_label = $this->get_settings_for_display( 'trade_change_label' );
		$trade_chart_label = $this->get_settings_for_display( 'trade_chart_label' );
		$trade_Trade_label = $this->get_settings_for_display( 'trade_Trade_label' );
		$trade_list = $this->get_settings_for_display( 'trade_list' );
		
	?>
	
    <!-- Trade Table Section -->
    <div class="trade-table-section pt-120 mt--255">
        <div class="container">
            <div class="trade-shadow">
                <div class="table-responsive">
                    <table class="table trade-table">
                        <thead>
                            <tr>
                                <th><?php echo esc_html($trade_number_label);?></th>
                                <th><?php echo esc_html($trade_name_label);?></th>
                                <th><?php echo esc_html($trade_price_label);?></th>
                                <th><?php echo esc_html($trade_change_label);?></th>
                                <th><?php echo esc_html($trade_chart_label);?></th>
                                <th><?php echo esc_html($trade_Trade_label);?></th>
                            </tr>
                        </thead>
                        <tbody>
						
						<?php		
						
						$number = 1 ;
							
						foreach ($trade_list as $item ) { ?>																									
							<tr>
                                <td><?php echo esc_html($number);?></td>
                                <td>
                                    <div class="currency-name">
                                        <div class="thumb">
                                            <img src="<?php echo esc_url($item['trade_currency_logo']['url']);?>" alt="<?php echo esc_attr($item['trade_currency_name']);?>">
                                        </div>
                                        <div class="content">
                                            <span class="name"><?php echo esc_html($item['trade_currency_name']);?></span>
                                            <span class="info"><?php echo esc_html($item['trade_currency_info']);?></span>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo esc_html($item['trade_currency_price']);?></td>
                                <td><?php echo esc_html($item['trade_currency_change']);?></td>
                                <td>
                                    <img src="<?php echo esc_url($item['trade_currency_graph']['url']);?>" alt="currency">
                                </td>
                                <td>
                                    <a href="<?php echo esc_url($item['trade_btn_link']);?>" class="cmn--btn"><?php echo esc_html($item['trade_btn_text']);?></a>
                                </td>
                            </tr>
			
						<?php 
						
							$number ++;
							
						} ?>	
                   
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Trade Table Section -->
					
			
	<?php

	}

}
