<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneCryptoFeatureWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-crypto-feature';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Crypto Feature' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_crypto_feature',
			[
				'label' => esc_html__( 'Crypto Feature', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'crypto_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'crypto_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Manage your portfolio',
			]
		);	
		
		$this->add_control(
			'crypto_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'There are many variations of passages of that majority have that suffered. ',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$crypto_icon = $this->get_settings_for_display( 'crypto_icon' )['url'];
		$crypto_title = $this->get_settings_for_display( 'crypto_title' );
		$crypto_content = $this->get_settings_for_display( 'crypto_content' );
		
		?>

		<div class="manage-portfolio-item">
			<div class="icon">
				<img src="<?php echo esc_url($crypto_icon);?>" alt="<?php echo esc_attr($crypto_title);?>" />
			</div>
			<div class="content">
				<h5 class="title"><?php echo esc_html($crypto_title);?></h5>
				<p>
					<?php echo bostone_wp_kses($crypto_content);?>
				</p>
			</div>
		</div>
					
<?php
	}

}
