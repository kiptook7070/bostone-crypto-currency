<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneClientWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-client';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Client' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_client',
			[
				'label' => esc_html__( 'Client', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'client_logo', [
				'label' => esc_html__( 'Logo', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'clinet_link', [
				'label' => esc_html__( 'Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'client_list',
			[
				'label' => esc_html__
				( 'Client List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'client_logo' => '',									
						'clinet_link' => '#',														
					],
		
				],
			]
		);		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$client_list = $this->get_settings_for_display( 'client_list' );
		
		?>

		<div class="sponsor-area sponsor-slider owl-theme owl-carousel p-0">  
			
			<?php
			foreach ($client_list as $item ) { ?>	
				<div class="sponsor-thumb pb-0">				
					<a href="<?php echo esc_url($item['clinet_link']);?>"><img src="<?php echo esc_url($item['client_logo']['url']);?>" alt="" /></a>									
				</div>
			<?php } ?>
	  
		</div>

		
<?php
	}

}