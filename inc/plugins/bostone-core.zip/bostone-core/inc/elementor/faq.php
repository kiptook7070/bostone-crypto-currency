<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



class BostoneFaqWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-faq';
	}
	
	public function get_title() {
		return esc_html__('FAQ' , 'bostone');
	}
	
	public function get_icon() {
		
		return 'eicon-shortcode';
	}	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_faq_content',
			[
				'label' => esc_html__( 'FAQ', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		
		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'default' => '1',
			]
		);
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'faq_active', [
				'label' => esc_html__( 'Active', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_block' => true,
			]
		);				
		
		$repeater->add_control(
			'faq_title', [
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'faq_content', [
				'label' => esc_html__( 'Content ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'faq_list',
			[
				'label' => esc_html__
				( 'FAQ List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'faq_active' => '',									
						'faq_title' => 'Frequently Asked Questions',									
						'faq_content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem dolorem dicta libero veritatis reiciendis quis pariatur magni.',																										
					],
		
				],
			]
		);		
		
		
		$this->end_controls_section();
		
		

	}
	
	protected function render(){

		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$faq_list = $this->get_settings_for_display( 'faq_list' );

		?>

			<div class="faq-wrapper <?php if($sec_style == '2'){ echo esc_attr('faq-wrapper-2 green-faq');}elseif($sec_style == '3'){ echo esc_attr('faq-wrapper-2 faq-bg-11');}elseif($sec_style == '4'){  echo esc_attr('faq-wrapper faq--wrapper-dark');} ?>">
				
				<?php
				
					$number = 1;
					foreach ($faq_list as $item ) { 
															
					?>	
					
					<div class="faq-item <?php if($item['faq_active'] == true){ echo esc_attr('open active');}?>">
						<div class="faq-title">
							<h5 class="title"><?php echo esc_html($item['faq_title']);?></h5>
							<span class="plus"></span>
						</div>
						<div class="faq-content">
							<p><?php echo bostone_wp_kses($item['faq_content']);?></p>
						</div>
					</div>	
					
					<?php 
					
					$number++ ;
					
					}
					?>
			</div>
		
		<?php 
	
	}

}
