<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneBenefitsWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-benefits';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Benefits' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_benefits_content',
			[
				'label' => esc_html__( 'Benefits', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => 'One',
					'2' => 'Two',
				),
				'default' => '1',
			]
		);		
		
		$this->add_control(
			'sec_ben_active',
			[
				'label' => esc_html__( 'Active', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => 'yes',
					'2' => 'no',
				),
				'default' => '2',
			]
		);
		
		$this->add_control(
			'ben_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'ben_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Early Bonus',
			]
		);	
		
		$this->add_control(
			'ben_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' There are many variations passages of Lorem Ipsum available suffered is that more alteration. ',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_ben_active = $this->get_settings_for_display( 'sec_ben_active' );
		$ben_icon = $this->get_settings_for_display( 'ben_icon' )['url'];
		$ben_title = $this->get_settings_for_display( 'ben_title' );
		$ben_content = $this->get_settings_for_display( 'ben_content' );
		
		?>

		<div class="benifit__card <?php if($sec_style == '2'){ echo esc_attr('bg--yellow');} if($sec_ben_active == '1'){ echo esc_attr('active');}?>">
			<div class="benifit__card-thumb">
				<img src="<?php echo esc_url($ben_icon);?>" alt="<?php echo esc_attr($ben_title);?>" />
			</div>
			<h4 class="benifit__card-title"><?php echo esc_html($ben_title);?></h4>
			<p>
				<?php echo bostone_wp_kses($ben_content);?>
			</p>
		</div>

<?php
	}

}
