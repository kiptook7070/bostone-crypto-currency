<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostonePricingChartThreeWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-pricing-chart-three';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Pricing Chart Three' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_pricing_chart_three',
			[
				'label' => esc_html__( 'Pricing Chart Three', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
	

		$this->add_control(
			'pri_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Uses of Fund',
			]
		);	
		
	
		$this->add_control(
			'pri_bg_color',
			[
				'label' => esc_html__( 'Background', 'bostone' ),
				'type' => \Elementor\Controls_Manager::COLOR ,
				'default' => '#fff',
			]
		);	
		
		$this->add_control(
			'pri_text_color',
			[
				'label' => esc_html__( 'Text Color', 'bostone' ),
				'type' => \Elementor\Controls_Manager::COLOR ,
				'default' => '#000',
			]
		);	
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'sec_pri_skname', [
				'label' => esc_html__( 'Skill Name', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'sec_pri_skper', [
				'label' => esc_html__( 'Skill Percent', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'sec_pri_list',
			[
				'label' => esc_html__
				( 'Pricing Skill List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'sec_pri_skname' => 'Accession and Partnerships',									
						'sec_pri_skper' => '5',																										
					],
		
				],
			]
		);		
		
		$this->end_controls_section();	

	}
	
	protected function render(){		

		$pri_title = $this->get_settings_for_display( 'pri_title' );
		$pri_bg_color = $this->get_settings_for_display( 'pri_bg_color' );
		$pri_text_color = $this->get_settings_for_display( 'pri_text_color' );
		$sec_pri_list = $this->get_settings_for_display( 'sec_pri_list' );
		
		?>

	 <div id="piechart" class="chart--size " style="background-color: <?php echo esc_attr($pri_bg_color);?>;"></div>

	<script>
	
	
        // Chart Two 
        google.charts.load("current", {packages:["corechart"]});
        google.charts.setOnLoadCallback(drawChartTwo);
        function drawChartTwo() {
            var data = google.visualization.arrayToDataTable([
                ['<?php echo esc_html($pri_title);?>', 'In Million'],
				<?php				
					foreach ($sec_pri_list as $item ) { ?>	
					['<?php echo esc_html($item['sec_pri_skname']);?>', <?php echo esc_html($item['sec_pri_skper']);?>],				
				<?php } ?>
				
				]);

            var options = {
            title: '<?php echo esc_html($pri_title);?>',
            pieSliceText: 'label',
            slices: {  
                4: {offset: 0.2},
                12: {offset: 0.3},
                14: {offset: 0.4},
                15: {offset: 0.5},
            },
                backgroundColor: '<?php echo esc_js($pri_bg_color);?>',
            color: 'red',
            fontSize: 16,
            bold: true,
            italic: true,
            titleTextStyle: {
                color: '<?php echo esc_js($pri_text_color);?>',
            },
            legend : {
                textStyle: {
                    color: '<?php echo esc_js($pri_text_color);?>', fontSize: 16
                }
            },
            legend: 'none',
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            chart.draw(data, options);
        }
    </script>
    <!-- Google Charts -->

<?php
	}

}
