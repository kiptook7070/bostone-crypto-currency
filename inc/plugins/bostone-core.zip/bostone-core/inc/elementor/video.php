<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneVideoWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-video';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Video' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_video',
			[
				'label' => esc_html__( 'Video', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'vid_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'bostone' ),
				'type' => \Elementor\Controls_Manager::COLOR ,
			]
		);	
		$this->add_control(
			'vid_bg',
			[
				'label' => esc_html__( 'Video Background', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'vid_url',
			[
				'label' => esc_html__( 'Url', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'https://www.youtube.com/watch?v=vQWlgd7hV4A',
			]
		);			
		
		$this->add_control(
			'vid_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Run your ICO from anytime',
			]
		);		

		$this->add_control(
			'vid_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Special Offer - 25% Off for this Month',
			]
		);		

		$this->add_control(
			'vid_btn_txt',
			[
				'label' => esc_html__( 'Button Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Read More',
			]
		);			
		
		$this->add_control(
			'vid_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
				
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$vid_bg = $this->get_settings_for_display( 'vid_bg' )['url'];
		$vid_bg_color = $this->get_settings_for_display( 'vid_bg_color' );
		$vid_url = $this->get_settings_for_display( 'vid_url' );
		$vid_subtitle = $this->get_settings_for_display( 'vid_subtitle' );
		$vid_title = $this->get_settings_for_display( 'vid_title' );
		$vid_btn_txt = $this->get_settings_for_display( 'vid_btn_txt' );
		$vid_btn_link = $this->get_settings_for_display( 'vid_btn_link' );
		
		?>

	   <!-- Video Section -->
		<section class="video-section pb-60 position-relative">
			<div class="video-bg bg--theme-1" style="background: <?php echo esc_attr($vid_bg_color);?>;"></div>
			<div class="container">
				<div class="video-wrapper-2 position-relative bg_img" data-img="<?php echo esc_url($vid_bg);?>">
					<a href="<?php echo esc_url($vid_url);?>" class="video--btn btn--white video-pop">
						<i class="fas fa-play"></i>
					</a>
				</div>
				<div class="row justify-content-center pt-5 mt-4">
					<div class="col-lg-8">
						<div class="section-header mw-100 section-header-center cl-white position-relative mb-0">
						<h6 class="section-name fw--regular"><?php echo esc_html($vid_subtitle);?></h6>
							<h2 class="section-title fw--regular"><?php echo bostone_wp_kses($vid_title);?></h2>
							<?php if($vid_btn_link){ ?>
								<a href="<?php echo esc_url($vid_btn_link);?>" class="cmn--btn bg--green rounded btn--white"><?php echo esc_html($vid_btn_txt);?></a>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Video Section -->
	
<?php
	}

}
