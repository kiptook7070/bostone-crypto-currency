<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneHowWorkWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-how-work';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('How Work' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_how_work',
			[
				'label' => esc_html__( 'How Work', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'sec_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Blockchain',
			]
		);		

		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'There many variations of passages of Ipsum the majority have suffered to some by injected humour.',
			]
		);		
	
	}
	
	protected function render(){		

		$sec_icon = $this->get_settings_for_display( 'sec_icon' )['url'];
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		

		?>
		
		<div class="how__item text-center">
			<div class="how__item-thumb">
				<img src="<?php echo esc_url($sec_icon);?>" alt="<?php echo esc_attr($sec_title);?>" />
			</div>
			<div class="how__item-content">
				<h4 class="how__item-title"><?php echo bostone_wp_kses($sec_title);?></h4>
				<p><?php echo bostone_wp_kses($sec_content);?></p>
			</div>
		</div>
						
<?php

	}

}
