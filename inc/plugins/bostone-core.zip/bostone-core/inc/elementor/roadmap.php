<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



class BostoneRoadmapWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-roadmap';
	}
	
	public function get_title() {
		return esc_html__('Roadmap' , 'bostone');
	}

	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_roadmap_content',
			[
				'label' => esc_html__( 'Roadmap', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'bostone_title_style',
			[
				'label' => esc_html__( 'Title Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'One', 'bostone' ),
					'2' => esc_html__( 'Two', 'bostone' ),
					'3' => esc_html__( 'Three', 'bostone' ),
				],
			]
		);
		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Sub Title ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Platform Implementstion',
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Roadmap',
			]
		);		
		
		$this->add_control(
			'sec_titlecontent',
			[
				'label' => esc_html__( 'Title Content ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.',
			]
		);		
		
		$this->add_control(
			'number_of_post',
			[
				'label' => esc_html__( 'Number of Posts', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '-1',
			]
		);		

				
		
		$this->end_controls_section();
		
		

	}
	
	protected function render(){
		$bostone_title_style = $this->get_settings_for_display( 'bostone_title_style' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_titlecontent = $this->get_settings_for_display( 'sec_titlecontent' );
		$number_of_post = $this->get_settings_for_display( 'number_of_post' );

		?>
		
		<!-- Road Map Section -->
		<section class="road-map-section" id="road">
			<div class="container">
				<?php

				if($bostone_title_style == '2'){ ?>
					<div class="section-header section-header-center ">
						<h6 class="section-name cl-1"><?php echo esc_html($sec_title);?></h6>
						<h2 class="section-title"><?php echo bostone_wp_kses($sec_subtitle);?></h2>
						<p class="section-text">
							<?php echo bostone_wp_kses($sec_titlecontent);?>
						</p>
					</div>
				<?php }elseif($bostone_title_style == '3'){ ?>
					<div class="section-header section-header-2">
						<div class="titles-area">
							<h6 class="section-name cl--green"><?php echo esc_html($sec_title);?></h6>
							<h2 class="section-title"><?php echo bostone_wp_kses($sec_subtitle);?></h2>
						</div>
						<p class="section-text">
							<?php echo bostone_wp_kses($sec_titlecontent);?>
						</p>
					</div>	
				<?php }else{ ?>
				
				<div class="section-header section-header-center">
					<h2 class="section-title fw--medium mb-0"><?php echo esc_html($sec_title);?></h2>
					<p>
					   <?php echo bostone_wp_kses($sec_titlecontent);?>
					</p>
				</div>
				
				<?php } ?>
				
				
				<div class="road__map-slider owl-theme owl-carousel">
					<?php
						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'roadmap' ),
							'posts_per_page'         => $number_of_post,
						);

						// The Query
						$bostone_roadmap_query = new WP_Query( $args );

						// The Loop
						if ( $bostone_roadmap_query->have_posts() ) {
							while ( $bostone_roadmap_query->have_posts() ) {
								$bostone_roadmap_query->the_post();
						
								?>
								
							   <div class="road__map-slide-item">
									<div class="road__map-slide-header">
										<h6 class="road__map-slide-title"><?php the_title();?></h6>
									</div>
									<div class="road__map-slide-body">
										<span><?php the_content();?></span>
									</div>
								</div>
								
					
						<?php }
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
						?>
				
		
				</div>
			</div>
		</section>
		<!-- Road Map Section -->

		<?php 
	
	}

}
