<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneButtonsWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-buttons';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Buttons' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_buttons_content',
			[
				'label' => esc_html__( 'Buttons', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => 'Border',
					'2' => 'Background ',
				),
				
				'default' => '1',
			]
		);
		
		$this->add_control(
			'sec_btn_icon',
			[
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'fas fa-paper-plane',
			]
		);	
		
		$this->add_control(
			'sec_btn_text',
			[
				'label' => esc_html__( 'Text', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Download Whitepaper',
			]
		);		
		
		$this->add_control(
			'sec_btn_link',
			[
				'label' => esc_html__( 'Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);

		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_btn_icon = $this->get_settings_for_display( 'sec_btn_icon' );
		$but_text = $this->get_settings_for_display( 'sec_btn_text' );
		$but_link = $this->get_settings_for_display( 'sec_btn_link' );
		
		?>

		<a href="<?php echo esc_url($but_link);?>" class="<?php if($sec_style == '2'){echo esc_attr('cmn--btn'); }else{ echo esc_attr('cmn--btn outline--theme ');};?>"><?php if($sec_btn_icon){ ?><i class="<?php echo esc_attr($sec_btn_icon);?>"></i><?php } ?> <?php echo esc_html($but_text);?></a>

		<?php
	
	}

}