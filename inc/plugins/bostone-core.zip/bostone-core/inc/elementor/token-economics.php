<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneTokenEconomicsWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-token-economics';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Token Economics' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_token_economics',
			[
				'label' => esc_html__( 'Token Economics', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Token Economics',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Dolore excepturi numquam maiores quia dolorem vero harum saepe fugiat vel atque recusandae tenetur?',
			]
		);		

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'sec_token_bg_color', [
				'label' => esc_html__( 'Background Color', 'bostone' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'label_block' => true,
			]
		);			
		
		$repeater->add_control(
			'sec_token_title', [
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'sec_token_subtitle', [
				'label' => esc_html__( 'Subtitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'sec_token_list',
			[
				'label' => esc_html__
				( 'Token List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'sec_token_bg_color' => '#0abe81',									
						'sec_token_title' => '17,050,000',									
						'sec_token_subtitle' => 'TOTAL TOKEN SUPPLY',																										
					],
		
				],
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_token_list = $this->get_settings_for_display( 'sec_token_list' );
		
		 ?>
		 
		<!-- Token Economics Section -->
		<section class="token-economics-section pt-120 pb-60" id="tokens">
			<div class="container">
				<div class="section-header section-header-center">
					<h2 class="section-title fw--medium"><?php echo esc_html($sec_title);?></h2>
					<p>
						<?php echo bostone_wp_kses($sec_content);?>
					</p>
				</div>
				
				<div class="row gy-5">
				<?php
				foreach ($sec_token_list as $item ) { ?>																									
					<div class="col-sm-10 col-md-6 col-lg-4">
						<div class="token__card" style="background-color: <?php echo esc_attr($item['sec_token_bg_color']);?>;">
							<h3 class="token__card-title"><?php echo esc_html($item['sec_token_title']);?></h3>
							<h6 class="token__card-subtitle"><?php echo esc_html($item['sec_token_subtitle']);?></h6>
						</div>
					</div>
				<?php } ?>
					
					
					
				</div>
			</div>
		</section>
		<!-- Token Economics Section -->
<?php
		
	}

}
