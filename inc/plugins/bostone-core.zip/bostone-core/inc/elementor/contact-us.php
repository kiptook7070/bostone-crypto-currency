<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneContactUsWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-contact-us';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Contact Us' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_contact_us',
			[
				'label' => esc_html__( 'Contact Us', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_bg_image',
			[
				'label' => esc_html__( 'Background Image', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Need a hand?',
			]
		);			
		
		$this->add_control(
			'sec_title_con',
			[
				'label' => esc_html__( 'Title Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Reach out to the world’s most reliable cryptocurrency.',
			]
		);			
		
		$this->add_control(
			'sec_con_form_shortcode',
			[
				'label' => esc_html__( 'Enter Contact Shortcode', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
			]
		);			
		
		$this->add_control(
			'sec_con_info_title',
			[
				'label' => esc_html__( 'Contact Info Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'REACH OUT NOW!',
			]
		);		
		
		$this->add_control(
			'sec_con_info_subtitle',
			[
				'label' => esc_html__( 'Contact Info SubTitle', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '(+00) 123 567990',
			]
		);			
		
		$this->add_control(
			'sec_con_info_title_content',
			[
				'label' => esc_html__( 'Contact Info Title Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Start the collaboration with us while figuring out the best solution based on your needs.',
			]
		);			
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'con_icon', [
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);				
		
		$repeater->add_control(
			'con_title', [
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'con_content', [
				'label' => esc_html__( 'Content ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'con_list',
			[
				'label' => esc_html__
				( 'Contact List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'con_icon' => 'las la-phone-volume',									
						'con_title' => 'Call us on: +03601 885399',									
						'con_content' => ' Our office hours are Monday – Friday, 9 am-6 pm ',																										
					],
		
				],
			]
		);		
				
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_bg_image = $this->get_settings_for_display( 'sec_bg_image' )['url'];
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_title_con = $this->get_settings_for_display( 'sec_title_con' );
		$sec_con_form_shortcode = $this->get_settings_for_display( 'sec_con_form_shortcode' );
		$sec_con_info_title = $this->get_settings_for_display( 'sec_con_info_title' );
		$sec_con_info_subtitle = $this->get_settings_for_display( 'sec_con_info_subtitle' );
		$sec_con_info_title_content = $this->get_settings_for_display( 'sec_con_info_title_content' );
		$con_list = $this->get_settings_for_display( 'con_list' );
	
		?>

		<!-- Contact Section -->
		<section class="contact-section position-relative pt-60">
			<div class="container">
				<div class="contact__wrapper-2 mb--60">
					<div class="map-shape bg_img bg_contain" data-img="<?php echo esc_url($sec_bg_image);?>"></div>
					<div class="row g-4 justify-content-center align-items-center position-relative">
						<div class="col-lg-7">
							<div class="section-header mb-4">
								<h3 class="section-title"><?php echo esc_html($sec_title);?></h3>
								<p><?php echo bostone_wp_kses($sec_title_con);?></p>
							</div>
							<div class="contact__wrapper contact__wrapper-3 me-lg-5">
								<div class="contact__form row g-3">
									<?php echo do_shortcode($sec_con_form_shortcode);?>
								</div>
							</div>
						</div>
						<div class="col-lg-5">
							<div class="contact__wrapper shadow-none p-0">
								<div class="section-header mb-4">
									<h6 class="section-name mb-3"><?php echo esc_html($sec_con_info_title);?></h6>
									<h4 class="section-title"><?php echo esc_html($sec_con_info_subtitle);?></h4>
									<p><?php echo bostone_wp_kses($sec_con_info_title_content);?></p>
								</div>
								<div class="row g-4">
									<?php		
										foreach ($con_list as $item ) { 
																				
										?>	
										
											<div class="col-md-12">
												<div class="contact__item">
													<div class="contact__icon cl-11">
														<i class="<?php echo esc_attr($item['con_icon']);?>"></i>
													</div>
													<div class="contact__content">
														<h6 class="title"><?php echo esc_html($item['con_title']);?></h6>
														<span class="info"><?php echo bostone_wp_kses($item['con_content']);?></span>
													</div>
												</div>
											</div>
										<?php 
									
										}
										?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Contact Section -->
			
		
<?php
	}

}
