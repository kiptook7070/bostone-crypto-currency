<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneAppWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-app';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('App' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_app',
			[
				'label' => esc_html__( 'App', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'app_section_img',
			[
				'label' => esc_html__( 'Image', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
			
		$this->add_control(
			'app_title',
			[
				'label' => esc_html__( 'Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Our Wallet App',
			]
		);	
		
		$this->add_control(
			'app_content',
			[
				'label' => esc_html__( 'Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'There are many variations of passages of Lorem Ipsum available but the dumm majority have suffered alteration in that some form by injected humour that a randomised don\'t look even slightly believable. ',
			]
		);		
		
		$this->add_control(
			'app_play_store_btn_title',
			[
				'label' => esc_html__( 'Play Store Button Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Available on the',
			]
		);		

		$this->add_control(
			'app_play_store_btn_details',
			[
				'label' => esc_html__( 'Play Store Button Details', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Play Apps Store',
			]
		);		
		
		$this->add_control(
			'app_play_store_btn_link',
			[
				'label' => esc_html__( 'Play Store Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);		
		
		$this->add_control(
			'app_ios_store_btn_title',
			[
				'label' => esc_html__( 'Play Store Button Title', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Available on the',
			]
		);		

		$this->add_control(
			'app_ios_store_btn_details',
			[
				'label' => esc_html__( 'Ios Store Button Details', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'iOS Apps Store',
			]
		);		
		
		$this->add_control(
			'app_ios_store_btn_link',
			[
				'label' => esc_html__( 'Play Store Button Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);		
				
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'sec_app_content', [
				'label' => esc_html__( 'App Content', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		
		
		$this->add_control(
			'sec_app_list',
			[
				'label' => esc_html__
				( 'App List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																														
						'sec_app_content' => 'Mouthwatering leading how real.  ',																										
					],
		
				],
			]
		);		
		
		$this->end_controls_section();	
		

	}
	
	protected function render(){		

		$app_section_img = $this->get_settings_for_display( 'app_section_img' )['url'];
		$app_title = $this->get_settings_for_display( 'app_title' );
		$app_content = $this->get_settings_for_display( 'app_content' );
		$app_play_store_btn_title = $this->get_settings_for_display( 'app_play_store_btn_title' );
		$app_play_store_btn_details = $this->get_settings_for_display( 'app_play_store_btn_details' );
		$app_play_store_btn_link = $this->get_settings_for_display( 'app_play_store_btn_link' );
		$app_ios_store_btn_title = $this->get_settings_for_display( 'app_ios_store_btn_title' );
		$app_ios_store_btn_details = $this->get_settings_for_display( 'app_ios_store_btn_details' );
		$app_ios_store_btn_link = $this->get_settings_for_display( 'app_ios_store_btn_link' );
		$sec_app_list = $this->get_settings_for_display( 'sec_app_list' );
		
		?>

		<section class="apps-section pt-60 pb-60 overflow-hidden body-bg clippy--7-rev">
            <div class="container">
                <div class="row pt-60 pb-60 gy-5 align-items-center">
                    <div class="col-lg-7">
                        <div class="about--content wallet-app-content">
                            <div class="section-header mb-4">
                                <h2 class="section-title"><?php echo esc_html($app_title);?></h2>
                            </div>
                            <p class="mb-4"><?php echo bostone_wp_kses($app_content);?> </p>
                            <ul class="about--list checked-style">
							  <?php
								foreach ($sec_app_list as $item ) { ?>																									
									<li class="text-body">
										<?php echo esc_html($item['sec_app_content']);?>
									</li>

								<?php } ?>

                            </ul>
							
                            <div class="app-btn-area">
								<?php if($app_play_store_btn_link){ ?>
                                <a href="<?php echo esc_url($app_play_store_btn_link);?>" class="app-btn active">
                                    <div class="icon">
                                        <i class="lab la-google-play"></i>
                                    </div>
                                    <div class="cont">
                                        <span class="btn-details"><?php echo esc_html($app_play_store_btn_title);?></span>
                                        <span class="btn-title"><?php echo esc_html($app_play_store_btn_details);?></span>
                                    </div>
                                </a>
								<?php } if($app_ios_store_btn_link){ ?>
                                <a href="<?php echo esc_url($app_ios_store_btn_link);?>" class="app-btn">
                                    <div class="icon">
                                        <i class="lab la-apple"></i>
                                    </div>
                                    <div class="cont">
                                        <span class="btn-details"><?php echo esc_html($app_ios_store_btn_title);?></span>
                                        <span class="btn-title"><?php echo esc_html($app_ios_store_btn_details);?></span>
                                    </div>
                                </a>
								<?php } ?>
                            </div>
							
                        </div>
                    </div>
                    <div class="col-lg-5 d-none d-lg-block">
                       <img src="<?php echo esc_url($app_section_img);?>" alt="<?php echo esc_attr($app_title);?>">
                    </div>
                </div>
            </div>
        </section>
		
	

<?php
	}

}
