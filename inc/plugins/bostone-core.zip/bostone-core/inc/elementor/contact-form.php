<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BostoneContactFormWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-contact-form';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Contact Form' , 'bostone');
	}
	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_contact_form',
			[
				'label' => esc_html__( 'Contact Form', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'con_shortcode',
			[
				'label' => esc_html__( 'Enter Shortcode', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '',
			]
		);		
		

		$this->end_controls_section();

	}
	
	protected function render(){		

		$con_shortcode = $this->get_settings_for_display( 'con_shortcode' );
		
		 ?>
		 
		<div class="contact__wrapper h-100">
			<div class="contact__form">
				<?php echo do_shortcode($con_shortcode);?>
			</div>
		</div>

	
<?php
	}

}
