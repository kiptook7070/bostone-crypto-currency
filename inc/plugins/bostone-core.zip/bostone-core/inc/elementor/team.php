<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



class BostoneTeamWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'bostone-team';
	}
	
	public function get_title() {
		return esc_html__('Team' , 'bostone');
	}
	
	public function get_icon() {
		
		return 'eicon-shortcode';
	}	
	public function get_categories() {
		return ['bostone-category'];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
		'bostone_team_content',
			[
				'label' => esc_html__( 'Team Content', 'bostone' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'bostone' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'options' => array(
					'1' => 'One',
					'2' => 'Two',
					'3' => 'Three',
					'4' => 'Four',
				),
				'default' => '1',
			]
		);
		
		$this->add_control(
			'sec_img',
			[
				'label' => esc_html__( 'Image ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);			

		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Marina Mojo',
			]
		);		
		
		$this->add_control(
			'sec_designation',
			[
				'label' => esc_html__( 'Designation ', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Developer',
			]
		);		
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'team_social_icon', [
				'label' => esc_html__( 'Icon', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'team_social_link', [
				'label' => esc_html__( 'Link', 'bostone' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'team_social_list',
			[
				'label' => esc_html__
				( 'Team Social List', 'bostone' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																							
						'team_social_icon' => 'fab fa-facebook-f',																					
						'team_social_link' => '#',														
					],
		
				],
			]
		);		
		
		
		$this->end_controls_section();
		
		

	}
	
	protected function render(){
		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_img = $this->get_settings_for_display( 'sec_img' )['url'];
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_designation = $this->get_settings_for_display( 'sec_designation' );
		$team_social_list = $this->get_settings_for_display( 'team_social_list' );

		if($sec_style == '2'){ ?>
			
		<div class="team__item-3">
			<div class="team__thumb">
				<img src="<?php echo esc_url($sec_img);?>" alt="<?php echo esc_attr($sec_title);?>"/>
			</div>
			<div class="team__content">
				<h5 class="title"><?php echo esc_html($sec_title);?></h5>
				<span class="info"><?php echo esc_html($sec_designation);?></span>
				<ul class="social">
					<?php
					foreach ($team_social_list as $item ) { ?>																									
						<li><a href="<?php echo esc_url($item['team_social_link']);?>"><i class="<?php echo esc_attr($item['team_social_icon']);?>"></i></a></li>
					<?php } ?>
				</ul>
			</div>
		</div>

		<?php }elseif($sec_style == '3'){ ?>
		
			<div class="team-box-9 section-bg">
				<div class="team-thumb">
					<img src="<?php echo esc_url($sec_img);?>" alt="<?php echo esc_attr($sec_title);?>"/>
				</div>
				<div class="team-content">
					<h6 class="title"><?php echo esc_html($sec_title);?></h6>
					<span class="info cl-9"><?php echo esc_html($sec_designation);?></span>
					<ul class="social">
					<?php
					foreach ($team_social_list as $item ) { ?>																									
						<li><a href="<?php echo esc_url($item['team_social_link']);?>"><i class="<?php echo esc_attr($item['team_social_icon']);?>"></i></a></li>
					<?php } ?>
					</ul>
				</div>
			</div>			
		<?php }elseif($sec_style == '4'){ ?>
			<div class="team__item-4">
				<div class="team__thumb">
					<img src="<?php echo esc_url($sec_img);?>" alt="<?php echo esc_attr($sec_title);?>"/>
				</div>
				<div class="team__content">
					<h5 class="title text-white"><?php echo esc_html($sec_title);?></h5>
					<span class="info"><?php echo esc_html($sec_designation);?></span>
					<ul class="social">
					<?php
					foreach ($team_social_list as $item ) { ?>																									
						<li><a href="<?php echo esc_url($item['team_social_link']);?>"><i class="<?php echo esc_attr($item['team_social_icon']);?>"></i></a></li>
					<?php } ?>
					</ul>
				</div>
			</div>			
		<?php }else{ ?>

		
		<div class="team-box cl-2">
			<div class="team-thumb">
				<img src="<?php echo esc_url($sec_img);?>" alt="<?php echo esc_attr($sec_title);?>"/>
				<ul class="social-icons">
					<?php
					foreach ($team_social_list as $item ) { ?>																									
						<li><a href="<?php echo esc_url($item['team_social_link']);?>"><i class="<?php echo esc_attr($item['team_social_icon']);?>"></i></a></li>
					<?php } ?>

				</ul>
			</div>
			<div class="team-content">
				<h4 class="title"><?php echo esc_html($sec_title);?></h4>
				<h6 class="info"><?php echo esc_html($sec_designation);?></h6>
			</div>
		</div>		

		<?php } ?>
		
	
		
		<?php 
	
	}

}
