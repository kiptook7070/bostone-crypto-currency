<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "bostone";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'bostone/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */


    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,

         'disable_tracking' => true,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Bostone Options', 'bostone' ),
        'page_title'           => esc_html__( 'Bostone Options', 'bostone' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => false,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => 3,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    );

 

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( esc_html__( '', 'bostone' ), $v );
    } else {
        $args['intro_text'] = esc_html__( '', 'bostone' );
    }

    // Add content after the form.
    $args['footer_text'] = esc_html__( '', 'bostone' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'bostone' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'bostone' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'bostone' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'bostone' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>', 'bostone' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

     // -> START Basic Fields
	  
	Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General Settings', 'bostone' ),
        'id'               => 'bostone-general-setting',
		'icon'             => 'el el-home-alt',
        'customizer_width' => '400px',
        'fields'           => array(

			array(
                'id'       => 'bostone_header_opt',
                'type'     => 'info',
                'style'     => 'success',
                'title'    => esc_html__('Header Section', 'bostone'),
            ), 		

			array(
                'id'       => 'bostone_header_dis_opt',
                'type'     => 'select',
                'title'    => esc_html__('Display Header ', 'bostone'),
                'subtitle' => esc_html__('Select option here', 'bostone'),
				'options'  => array(
					'1' => 'yes',
					'2' => 'no',
				),
				'default'  => '1',
            ),
			
			array(
                'id'       => 'bostone_header_style',
                'type'     => 'select',
                'title'    => esc_html__('Header Style ', 'bostone'),
                'subtitle' => esc_html__('Select option here', 'bostone'),
				'options'  => array(
					'1' => 'Style 1',
					'2' => 'Style 2',
				),
				'default'  => '1',
            ),
			
			array(
				'id'       => 'bostone_languages_opt',
				'type'     => 'slides',
				'title' => esc_html__('Languages', 'bostone'),
				'placeholder' => array(
					'title'           => esc_html__('Enter Name', 'bostone'),
					'url'             => esc_html__('Enter Link', 'bostone'),
				),
				'show' => array(
					'title' => true,
					'url' => false,
					'description' => false,
					'thumb' => false,
				),			
			),
			
			array(
				'id'       => 'bostone_head_btn_text',
				'type'     => 'text',
				'title'    => esc_html__('Button Text', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Get Started'
			),		
			
			array(
				'id'       => 'bostone_head_btn_link',
				'type'     => 'text',
				'title'    => esc_html__('Button Link', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => '#'
			),	
			array(
                'id'       => 'bostone_preload_opt',
                'type'     => 'info',
                'style'     => 'success',
                'title'    => esc_html__('Preloader Section', 'bostone'),
            ), 
			
				
            array(
                'id'       => 'bostone_preloader_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Display Preloader', 'bostone'),
                'subtitle' => esc_html__('If yes then click the checkbox.', 'bostone'),
                'default'  => '1'// 1 = on | 0 = off
            ), 	
			
			array(
                'id'       => 'bostone_homepage_opt',
                'type'             => 'checkbox',
                'title'            => esc_html__('Only Enable Home Page', 'bostone'), 
				'default'  => '0',
                'subtitle'         => esc_html__('if check this option preloader only will be enable for home page', 'bostone'),
				'required' => array( 'bostone_preloader_opt', '=', '1' ),
            ),				
			
            array(
                'id'       => 'bostone_scroll_up_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Scroll Up', 'bostone'),
                'subtitle' => esc_html__('If yes then click the checkbox.', 'bostone'),
                'default'  => '1'// 1 = on | 0 = off
            ),      

	
        )
    ) );
	
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Banner Settings', 'bostone' ),
        'id'               => 'bostone-banner-setting',
		'icon'             => 'el el-th',
        'customizer_width' => '400px',
        'fields'           => array(
	
			array(
				'id'       => 'bostone_banner_img_opt',
				'type'     => 'media',
				'compiler' => true,
				'title'    => esc_html__('Main Banner Image', 'bostone'), 
				'subtitle' => esc_html__('upload banner image here', 'bostone'),
				'default'  => array(
					'url'=> esc_url(get_template_directory_uri()).'/assets/images/shapes-bg/banner-shapes-bg.png'
				  ),
			), 
						
			array(
				'id'       => 'bostone_banner_text_info',
				'type'     => 'info',
				'title'    => esc_html__('Banner Text Options', 'bostone'), 
				'style'     => 'success',
			),	
			
			array(
				'id'       => 'bostone_blog_title',
				'type'     => 'text',
				'title'    => esc_html__('Blog Page Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Blog Post'
			),		

			array(
				'id'       => 'bostone_home_text',
				'type'     => 'text',
				'title'    => esc_html__('Home Text', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Home '
			),		

			array(
				'id'       => 'bostone_archive_title',
				'type'     => 'text',
				'title'    => esc_html__('Archive Page Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Archive'
			),	
			
			array(
				'id'       => 'bostone_search_title',
				'type'     => 'text',
				'title'    => esc_html__('Search Page Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Search Results '
			),			

			array(
				'id'       => 'bostone_shop_title',
				'type'     => 'text',
				'title'    => esc_html__('Shop Page Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Shop'
			),			

			
			array(
				'id'       => 'bostone_404_title_text',
				'type'     => 'text',
				'title'    => esc_html__('404 Page Title Text', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => '404 Error'
			),		

			array(
				'id'       => 'bostone_404_sub_title_text',
				'type'     => 'text',
				'title'    => esc_html__('404 Page Sub Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Page Not Found'
			),	
							
        )
    ) );    
	
	Redux::setSection( $opt_name, array(
        'title'            => esc_html__( '404 Page Settings', 'bostone' ),
        'id'               => 'bostone-404-page-setting',
		'icon'             => 'el el-trash-alt',
        'customizer_width' => '400px',
        'fields'           => array(
	

			array(
				'id'       => 'bostone_404_image',
				'type'     => 'media',
				'title'    => esc_html__('404 Image', 'bostone'), 
				'subtitle' => esc_html__('upload image here ', 'bostone'),
				'transparent'     => false,
				'default'  => array(
					'url'=> esc_url(get_template_directory_uri()).'/assets/images/error.png'
				  ),

			),				
			
			array(
				'id'       => 'bostone_404_page_title',
				'type'     => 'textarea',
				'title'    => esc_html__('Page Title', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Page Not Found'
			),	
			
			array(
				'id'       => 'bostone_404_page_descrption',
				'type'     => 'textarea',
				'title'    => esc_html__('Page Description', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'We’re not able to find what you were looking for.'
			),	
			
			array(
				'id'       => 'bostone_404_btn_text',
				'type'     => 'text',
				'title'    => esc_html__('Button Text', 'bostone'), 
				'subtitle' => esc_html__('enter text here ', 'bostone'),
				'transparent'     => false,
				'default'  => 'Back To Home'
			),	
		
        )
    ) );

   Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Footer Settings', 'bostone' ),
        'id'               => 'bostone-foooter-setting',
        'icon'             => 'el el-stop-alt',
        'customizer_width' => '400px',
        'fields'           => array(

	
				array(
					'id'       => 'bostone_copyright_text',
					'type'             => 'editor',
					'title'            => esc_html__('Copyright Text', 'bostone'), 
					'subtitle'         => esc_html__('Write copyright text here.', 'bostone'),
					'default'          => 'Copyright © 2022 <a href="#">Boston</a> all right reserved.',
					'args'   => array(
						'teeny'            => true,
						'textarea_rows'    => 4
					)
				),
			
			
        )
    ) );
	
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Custom Css Settings', 'bostone' ),
        'id'               => 'bostone-custom-css-setting',
		'icon'             => 'el el-magic',
        'customizer_width' => '400px',
        'fields'           => array(
		
			array(
                'id'       => 'bostone_custom_css_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Custom Css Option', 'bostone'),
                'subtitle' => esc_html__('Show / Hide Option', 'bostone'),
                'default'  => '0'// 1 = on | 0 = off
            ), 

			array(
				'id'       => 'bostone_theme_color',
				'type'     => 'color',
				'title'    => esc_html__('Theme Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#007aff'
			),				
			
			array(
				'id'       => 'bostone_theme_rgbacolor',
				'type'     => 'color_rgba',
				'title'    => esc_html__('Theme RGBA Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => 'rgba(0, 122, 255, 0.7)',
				'output'    => array(         
					'background-color' => '.road__map-slide-item .road__map-slide-body, .road__map-slide-item:after'  
				)
			),				
					

			array(
				'id'       => 'bostone_header_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Header Color', 'bostone'), 
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
			),			
							
		
			array(
				'id'       => 'bostone_menu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Text Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),	
			
			array(
				'id'       => 'bostone_menu_text_hover_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Text Hover', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),					
			
			array(
				'id'       => 'bostone_sticky_menu_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Sticky Menu Backgrund Color', 'bostone'), 
				'subtitle' => esc_html__('choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#007aff'
			),			
			
			array(
				'id'       => 'bostone_sticky_menu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Sticky Menu Text Color', 'bostone'), 
				'subtitle' => esc_html__('Please use color ', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),					
			array(
				'id'       => 'bostone_sticky_menu_text_hover_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Sticky Text Hover / Active Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),	
						
			array(
				'id'       => 'bostone_submenu_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Background Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#ffffff'
			),		
			
			array(
				'id'       => 'bostone_submenu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Text Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#0d1856'
			),		
					
			array(
				'id'       => 'bostone_submenu_hover_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Hover Background Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#007aff'
			),	
			
			array(
				'id'       => 'bostone_submenu_hover_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Hover text Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),				
			
			array(
				'id'       => 'bostone_head_btn_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Header Button BG Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#0abe81'
			),	
			
			array(
				'id'       => 'bostone_head_btn_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Header Button Text Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),			

			array(
				'id'       => 'bostone_banner_bg_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Banner Color', 'bostone'), 
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
			),			

			array(
				'id'       => 'bostone_banner_bg_color',
				'type'     => 'text',
				'title'    => esc_html__('Banner Background Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '-webkit-linear-gradient(0deg, #007aff 0%, rgba(0, 122, 255, 0.9) 100%)'
			),	
			
			array(
				'id'       => 'bostone_banner_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Banner Text Color', 'bostone'), 
				'subtitle' => esc_html__('Choice color here', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),	
			
			array(
				'id'       => 'bostone_foot_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Footer Color', 'bostone'), 
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
			),	
			
			array(
                'id'       => 'bostone_foot_bgcolor',
                'type'             => 'color',
                'title'            => esc_html__('Footer Background Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#061b49'
            ),	
			

			array(
                'id'       => 'bostone_foot_title_color',
                'type'             => 'color',
                'title'            => esc_html__('Footer Title Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#fff'
            ),						
			
			array(
                'id'       => 'bostone_foot_color',
                'type'             => 'color',
                'title'            => esc_html__('Footer Text Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#f8f9fa'
            ),			

			array(
                'id'       => 'bostone_foot_link_color',
                'type'             => 'text',
                'title'            => esc_html__('Footer Link Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => 'rgba(255, 255, 255, 0.8)'
            ),				
			
			array(
                'id'       => 'bostone_foot_link_hov_color',
                'type'             => 'text',
                'title'            => esc_html__('Footer Link Hover Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => 'rgba(255, 255, 255, 1)'
            ),	
			
			array(
				'id'       => 'bostone_spinning_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Preloader Color', 'bostone'), 
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
			),	
			
			array(
                'id'       => 'bostone_spinner_bgcolor',
                'type'             => 'color',
                'title'            => esc_html__('Preloader Background Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#007aff'
            ),		

			array(
                'id'       => 'bostone_spinner_color',
                'type'             => 'color',
                'title'            => esc_html__('Preloader Color', 'bostone'), 		
                'subtitle'         => esc_html__('choice color here', 'bostone'),
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#fff'
            ),	
			

			array(
				'id'       => 'bostone_scroll_up_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Scrollup Color', 'bostone'), 
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
			),
			
			array(
				'id'       => 'bostone_scroll_up_col_icon',
				'type'     => 'color',
				'title'    => esc_html__('Icon Color', 'bostone'), 
				'subtitle' => esc_html__('Please use color ', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default' => '#fff'
			),		
			
			array(
				'id'       => 'bostone_scroll_up_col_bg',
				'type'     => 'color',
				'title'    => esc_html__('Background Color', 'bostone'), 
				'subtitle' => esc_html__('Please use color ', 'bostone'),
				'transparent'     => false,
				'required' => array( 'bostone_custom_css_opt', '=', '1' ),
				'default' => '#007aff'
			),				
						
						
        )
    ) );	
	

 


    Redux::setSection( $opt_name, array(
        'icon'            => 'el el-list-alt',
        'title'           => esc_html__( 'Customizer Only', 'bostone' ),
        'desc'            => esc_html__( '<p class="description">This Section should be visible only in Customizer</p>', 'bostone' ),
        'customizer_only' => true,
        'fields'          => array(
            array(
                'id'              => 'opt-customizer-only',
                'type'            => 'select',
                'title'           => esc_html__( 'Customizer Only Option', 'bostone' ),
                'subtitle'        => esc_html__( 'The subtitle is NOT visible in customizer', 'bostone' ),
                'desc'            => esc_html__( 'The field desc is NOT visible in customizer.', 'bostone' ),
                'customizer_only' => true,
                //Must provide key => value pairs for select options
                'options'         => array(
                    '1' => esc_html__('Opt 1' , 'bostone'),
                    '2' => esc_html__('Opt 2' , 'bostone'),
                    '3' => esc_html__('Opt 3' , 'bostone')
                ),
                'default'         => '2'
            ),
        )
    ) );

    if ( file_exists( get_template_directory() . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => esc_html__( 'Documentation', 'bostone' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => get_template_directory() . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */


//define



include_once(bostoneDIR. '/inc/custom_css.php');