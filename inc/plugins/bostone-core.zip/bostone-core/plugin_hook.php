<?php
/*

Plugin Name: Bostone Core

Plugin URI: http://getmasum.com

Description: After install the bostone WordPress Theme, you must need to install this Plugin then will get all Features of bostone WP Theme.

Author: Masum Billah

Author URI: http://www.getmasum.com

Version: 1.0

Text Domain: bostone-core

*/


//define

define( 'bostoneDIR', dirname( __FILE__ ) ); 

// Add main files

include_once(bostoneDIR. '/inc/elementor-active.php');
include_once(bostoneDIR. '/inc/custom_posts.php');
include_once(bostoneDIR. '/inc/theme-options.php');
include_once(bostoneDIR. '/inc/bostone_metabox.php');
include_once(bostoneDIR. '/inc/widget/foot_about_widget.php');

//Add Elementor Category
function bostone_add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'bostone-category',
		[
			'title' => esc_html__( 'bostone', 'bostone' ),
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'bostone_add_elementor_widget_categories' );


// Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');